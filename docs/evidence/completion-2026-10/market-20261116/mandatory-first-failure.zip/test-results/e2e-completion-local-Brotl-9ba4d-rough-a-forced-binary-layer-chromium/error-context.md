# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/completion.spec.ts >> local Brotli WASM compiles and decodes through a forced binary layer
- Location: tests/e2e/completion.spec.ts:76:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.waitFor: Test timeout of 30000ms exceeded.
Call log:
  - waiting for locator('.advanced-result') to be visible

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - link "Skip to content" [ref=e2] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e3]:
    - link "decod.ing home" [ref=e4] [cursor=pointer]:
      - /url: /
      - img [ref=e5]
    - group [ref=e10]:
      - generic "Language" [ref=e11] [cursor=pointer]: English
    - button "Toggle color theme" [ref=e12] [cursor=pointer]:
      - img [ref=e13]
  - main [ref=e17]:
    - generic [ref=e19]:
      - heading "Paste an unfamiliar value here." [level=1] [ref=e20]
      - paragraph [ref=e21]:
        - text: Unknown text, garbled letters, long links or a QR photo. Read possible meanings and choose what to copy, on this device.
        - link "Check local processing" [ref=e22] [cursor=pointer]:
          - /url: /proof/
    - region "Universal decoder" [ref=e26]:
      - link "Only on this device" [ref=e28] [cursor=pointer]:
        - /url: /proof/
        - text: Only on this device
      - generic [ref=e30]:
        - generic [ref=e31]:
          - generic [ref=e32]: Paste text or drop a file
          - button "Clear" [disabled] [ref=e33]
        - textbox "Paste text or drop a file" [ref=e34]:
          - /placeholder: Tap here and paste
        - generic [ref=e35]:
          - button "Paste" [ref=e36] [cursor=pointer]
          - generic [ref=e37] [cursor=pointer]:
            - text: Photo / QR
            - button "Photo / QR" [ref=e38]
          - generic [ref=e39] [cursor=pointer]:
            - text: Open file
            - button "Open file" [ref=e40]
          - generic [ref=e41]: Max 10 MiB
      - group "Does one of these look familiar? Try an example." [ref=e42]:
        - generic [ref=e43]: Does one of these look familiar? Try an example.
        - generic [ref=e44]:
          - button "Garbled text" [ref=e45] [cursor=pointer]:
            - generic [ref=e46]: 文
            - strong [ref=e47]: Garbled text
          - button "Long link" [ref=e48] [cursor=pointer]:
            - generic [ref=e49]: ↗
            - strong [ref=e50]: Long link
          - button "Login token" [ref=e51] [cursor=pointer]:
            - generic [ref=e52]: ◇
            - strong [ref=e53]: Login token
          - button "Several layers" [ref=e54] [cursor=pointer]:
            - generic [ref=e55]: ≡
            - strong [ref=e56]: Several layers
          - button "Mail subject" [ref=e57] [cursor=pointer]:
            - generic [ref=e58]: "@"
            - strong [ref=e59]: Mail subject
          - button "Ten-digit number" [ref=e60] [cursor=pointer]:
            - generic [ref=e61]: "#"
            - strong [ref=e62]: Ten-digit number
          - button "QR photo" [ref=e63] [cursor=pointer]:
            - generic [ref=e64]: ▦
            - strong [ref=e65]: QR photo
      - group [ref=e66]:
        - generic "Copy feedback" [ref=e67] [cursor=pointer]
    - region "Start with your situation" [ref=e68]:
      - heading "Start with your situation" [level=2] [ref=e70]
      - navigation "Start with your situation" [ref=e71]:
        - list [ref=e72]:
          - listitem [ref=e73]:
            - link "Fix garbled text and Korean mojibake" [ref=e74] [cursor=pointer]:
              - /url: /fix-garbled-text/
              - text: Fix garbled text and Korean mojibake
              - generic [ref=e75]: →
          - listitem [ref=e76]:
            - link "Decode a garbled mail subject" [ref=e77] [cursor=pointer]:
              - /url: /decode-mail-subject/
              - text: Decode a garbled mail subject
              - generic [ref=e78]: →
          - listitem [ref=e79]:
            - link "Join separated Korean filename letters" [ref=e80] [cursor=pointer]:
              - /url: /normalize-korean-filename/
              - text: Join separated Korean filename letters
              - generic [ref=e81]: →
          - listitem [ref=e82]:
            - link "What encoding is this string?" [ref=e83] [cursor=pointer]:
              - /url: /what-encoding-is-this/
              - text: What encoding is this string?
              - generic [ref=e84]: →
          - listitem [ref=e85]:
            - link "Read a QR code before opening its link" [ref=e86] [cursor=pointer]:
              - /url: /decode-qr-before-opening/
              - text: Read a QR code before opening its link
              - generic [ref=e87]: →
          - listitem [ref=e88]:
            - link "Where does this link go?" [ref=e89] [cursor=pointer]:
              - /url: /where-does-this-link-go/
              - text: Where does this link go?
              - generic [ref=e90]: →
          - listitem [ref=e91]:
            - link "Is it safe to paste a JWT online?" [ref=e92] [cursor=pointer]:
              - /url: /is-it-safe-to-paste-jwt/
              - text: Is it safe to paste a JWT online?
              - generic [ref=e93]: →
          - listitem [ref=e94]:
            - link "How to tell if a string is Base64" [ref=e95] [cursor=pointer]:
              - /url: /how-to-tell-if-a-string-is-base64/
              - text: How to tell if a string is Base64
              - generic [ref=e96]: →
  - navigation "Primary" [ref=e97]:
    - link "Decode" [ref=e98] [cursor=pointer]:
      - /url: /
      - img [ref=e99]
      - text: Decode
    - link "Tools" [ref=e101] [cursor=pointer]:
      - /url: /tools/
      - img [ref=e102]
      - text: Tools
    - link "Saved" [ref=e104] [cursor=pointer]:
      - /url: /workspace/
      - img [ref=e105]
      - text: Saved
    - link "More" [ref=e107] [cursor=pointer]:
      - /url: /more/
      - img [ref=e108]
      - text: More
  - contentinfo [ref=e112]:
    - generic [ref=e113]:
      - link "decod.ing" [ref=e114] [cursor=pointer]:
        - /url: /
        - img [ref=e115]
        - generic [ref=e120]: decod.ing
      - paragraph [ref=e121]: Unknown text. Clear answers. On this device.
    - generic [ref=e122]:
      - link "Device data" [ref=e123] [cursor=pointer]:
        - /url: /data/
      - link "Check local processing" [ref=e124] [cursor=pointer]:
        - /url: /proof/
      - link "Bookmarklet" [ref=e125] [cursor=pointer]:
        - /url: /bookmarklet/
      - link "Sponsor" [ref=e126] [cursor=pointer]:
        - /url: /sponsor/
      - link "49 Tools" [ref=e127] [cursor=pointer]:
        - /url: /tools/
      - link "Privacy" [ref=e128] [cursor=pointer]:
        - /url: /privacy/
      - link "Terms" [ref=e129] [cursor=pointer]:
        - /url: /terms/
      - link "Support" [ref=e130] [cursor=pointer]:
        - /url: /support/
      - link "Method" [ref=e131] [cursor=pointer]:
        - /url: /methodology/
      - link "Desktop" [ref=e132] [cursor=pointer]:
        - /url: /download/
      - link "Changelog" [ref=e133] [cursor=pointer]:
        - /url: /changelog/
      - link "About" [ref=e134] [cursor=pointer]:
        - /url: /about/
    - generic [ref=e135]:
      - paragraph [ref=e136]:
        - generic [ref=e137]: No account. No upload. No generative AI. No tracking ads.
        - generic [ref=e138]: MUNOPS (문옵스) · Build c44df58 · 63 formats
      - generic [ref=e140]:
        - checkbox "Count actions only" [checked] [ref=e141]
        - text: Count actions only
```

# Test source

```ts
  1  | import type { Page } from '@playwright/test'
  2  | export async function openAdvanced(page: Page) {
  3  |   const details = page.locator('.advanced-result')
> 4  |   await details.waitFor({ state: 'visible' })
     |                 ^ Error: locator.waitFor: Test timeout of 30000ms exceeded.
  5  |   if (!(await details.evaluate((element) => (element as HTMLDetailsElement).open)))
  6  |     await details.locator(':scope > summary').click()
  7  | }
  8  | 
  9  | /** Pure tools update automatically; parser/generator tools keep an explicit run gesture. */
  10 | export async function runTool(page: import('@playwright/test').Page) {
  11 |   const run = page.getByRole('button', { name: 'Run locally', exact: true })
  12 |   if (await run.count()) await run.click()
  13 | }
  14 | 
```
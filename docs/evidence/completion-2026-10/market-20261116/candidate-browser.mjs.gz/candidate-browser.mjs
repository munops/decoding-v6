import { chromium } from '@playwright/test';
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const root='/Users/minhan/workspace/decoding-v6',dir=root+'/.wrangler/decoding-market-20261116';
const source=process.env.DECODING_EXPECTED_BUILD_SHA??execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const base=process.env.MARKET_CAPTURE_BASE??'http://127.0.0.1:4323';
const prefix=base.startsWith('https:')?'public':'candidate';
const browser=await chromium.launch({headless:true}),results=[];
try {
 for(const locale of ['en','ko']) {
  const context=await browser.newContext({permissions:['clipboard-read','clipboard-write'],locale:'en-US',serviceWorkers:'block',viewport:{width:1440,height:900},colorScheme:'light',reducedMotion:'reduce'}),p=await context.newPage();
  await context.addInitScript(()=>localStorage.setItem('decoding-count-optout','true'));
  await p.goto(base+(locale==='ko'?'/ko/':'/'));
  await p.locator('[data-sample-id="broken"]:enabled').waitFor();
  if(await p.locator('meta[name="application-build"]').getAttribute('content')!==source)throw Error('source mismatch');
  await p.locator('#decoder-input').fill('a2VlcC1teS10ZXh0');
  await p.locator('.answer-final .output-view').filter({hasText:'keep-my-text'}).waitFor();
  for(const width of [1440,390,320]) {
   await p.setViewportSize({width,height:900});
   const r=await p.evaluate(()=>({path:location.pathname,lang:document.documentElement.lang,width:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth,source:document.querySelector('meta[name="application-build"]').content,selected:document.querySelector('.answer-final .output-view')?.textContent,smallTargets:[...document.querySelectorAll('.result-layer-choices button')].filter(el=>el.getBoundingClientRect().height<44).length}));
   if(r.source!==source||r.lang!==locale||r.overflow||r.selected!=='keep-my-text'||r.smallTargets)throw Error(JSON.stringify(r));results.push(r);
   if(locale==='ko'&&width===390){await p.locator('.answer-final').scrollIntoViewIfNeeded();await p.screenshot({path:dir+'/'+prefix+'-result-390.png'});}
  }
  await p.locator('.answer-final-heading button').click();
  if(await p.evaluate(()=>navigator.clipboard.readText())!=='keep-my-text')throw Error('recommended copy');
  await p.locator('.result-layer-choices button').nth(1).click();
  await p.locator('.answer-final-heading button').click();
  if(await p.evaluate(()=>navigator.clipboard.readText())!=='91 e7 a9 fa 6c be b5 ec 6d')throw Error('explicit copy');
  results.push({locale,recommendedCopy:true,explicitByteCopy:true});
  if(locale==='ko') {
   await p.evaluate(()=>document.documentElement.style.fontSize='200%');
   const r=await p.evaluate(()=>({width:innerWidth,rootFont:getComputedStyle(document.documentElement).fontSize,overflow:document.documentElement.scrollWidth-innerWidth}));if(r.rootFont!=='32px'||r.overflow)throw Error('200% reflow');results.push(r);
   await p.locator('.answer-final').scrollIntoViewIfNeeded();await p.screenshot({path:dir+'/'+prefix+'-result-320-200.png'});
   await p.evaluate(()=>document.documentElement.style.fontSize='');await p.setViewportSize({width:390,height:844});
   for(const [route,input] of [['decode-mail-subject','=?UTF-8?B?7JWI64WV7ZWY7IS47JqU?='],['fix-garbled-text','ì•ˆë…•í•˜ì„¸ìš”']]){
    await p.goto(base+'/ko/'+route+'/');await p.locator('#decoder-input').fill(input);await p.locator('.answer-final .output-view').filter({hasText:'안녕하세요'}).waitFor();await p.locator('.answer-final-heading button').click();if(await p.evaluate(()=>navigator.clipboard.readText())!=='안녕하세요')throw Error(route+' copy');results.push({route,wholeInput:true,output:'안녕하세요',copy:true});
   }
   await p.locator('#decoder-input').fill('abcde');await p.locator('.answer-card .next-step').filter({hasText:'원문을 끝까지 복사'}).waitFor();results.push({unsupportedRecovery:true});
   await p.locator('.answer-card .next-step').scrollIntoViewIfNeeded();await p.screenshot({path:dir+'/'+prefix+'-recovery-390.png'});
   await p.locator('footer').scrollIntoViewIfNeeded();await p.screenshot({path:dir+'/'+prefix+'-footer-390.png'});
  }
  await context.close();
 }
 const receipt={checkedAt:new Date().toISOString(),sourceRevision:source,target:base,freshProductionPreview:!base.startsWith('https:'),cleanContexts:true,countingOptout:true,serviceWorkers:'block',results};writeFileSync(dir+(base.startsWith('https:')?'/public-capture.json':'/candidate-capture.json'),JSON.stringify(receipt));console.log({source,base,checks:results.length,status:'passed'});
}finally{await browser.close()}

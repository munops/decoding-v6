// Additional action-time fences around the unchanged product release entrypoint.
if (process.argv[1]?.endsWith('/scripts/local-delivery.mjs') && process.argv[2]==='deploy-web') {
 const {readFileSync,writeFileSync}=await import('node:fs');
 const {createHash}=await import('node:crypto');
 const {syncBuiltinESMExports}=await import('node:module');
 const cp=await import('node:child_process');
 const {assertClaimsFreshReadOnly}=await import('../../../scripts/lib/work-claims.mjs');
 const {validateReleaseWaveFile,parseReleaseWaveYaml}=await import('../../../scripts/check-release-wave.mjs');
 const {assertArtifactManifest}=await import('../../../scripts/lib/source-bound-web-release.mjs');
 const {reserveReleasePhase,assertReleasePhase,finishReleasePhase}=await import('../../../scripts/lib/release-phase-reservation.mjs');
 const dir='/Users/minhan/workspace/decoding-v6/.wrangler/decoding-market-20261116';
 const cfg=JSON.parse(readFileSync(dir+'/execution.json','utf8')),original=cp.default.execFileSync;
 const hash=b=>createHash('sha256').update(b).digest('hex');
 const git=args=>original('git',['-C',cfg.root,...args],{encoding:'utf8',stdio:['ignore','pipe','pipe']}).trim();
 function assertFacts(){
  if(git(['rev-parse','HEAD'])!==cfg.executorRevision||git(['status','--porcelain=v1','--untracked-files=all']))throw Error('source identity drift');
  if(git(['diff','--name-only',`${cfg.sourceRevision}..HEAD`]).split('\n').filter(Boolean).some(p=>![cfg.waveRef,'docs/operations/local-delivery.json'].includes(p)))throw Error('runtime drift');
  if(hash(readFileSync(cfg.root+'/scripts/local-delivery.mjs'))!==cfg.adapterSha256||hash(readFileSync(cfg.root+'/wrangler.toml'))!==cfg.configSha256)throw Error('adapter or config drift');
  const errors=validateReleaseWaveFile(cfg.root+'/'+cfg.waveRef,{requireCurrentAuthorization:true});if(errors.length)throw Error(errors.join(';'));
  const wave=parseReleaseWaveYaml(readFileSync(cfg.root+'/'+cfg.waveRef,'utf8'));
  if(wave.wave_id!==cfg.waveId||wave.source_revision!==cfg.sourceRevision||!wave.approval.approved_action_ids.includes(cfg.webAction))throw Error('wave identity drift');
  assertClaimsFreshReadOnly([cfg.claim],{lane:'owner_lane',mutationModes:true});
  const bytes=readFileSync(dir+'/candidate.json');if(hash(bytes)!==cfg.manifestFileSha256)throw Error('manifest drift');
  const manifest=JSON.parse(bytes);assertArtifactManifest(cfg.root+'/apps/web/dist',manifest.rows);
 }
 function before(){return JSON.parse(original(process.execPath,[dir+'/provider-readback.mjs','before'],{cwd:cfg.root,env:process.env,encoding:'utf8',stdio:['ignore','pipe','pipe']}))}
 cp.default.execFileSync=function(file,args,options){
  if(file==='pnpm'&&Array.isArray(args)&&args[0]==='exec'&&args[1]==='wrangler'&&args[2]==='deploy'){
   const expected=['exec','wrangler','deploy','--config','wrangler.toml','--strict','--keep-vars','--var',`BUILD_SHA:${cfg.sourceRevision}`,'--message',`owner-lane local production release ${cfg.sourceRevision}`];
   if(JSON.stringify(args)!==JSON.stringify(expected)||options?.env?.CLOUDFLARE_ACCOUNT_ID!==cfg.account)throw Error('non-exact provider command');
   assertFacts();before();
   const phase=reserveReleasePhase({waveId:cfg.waveId,actionId:cfg.webAction,resource:cfg.workerResource,sourceRevision:cfg.sourceRevision,artifactDigest:cfg.artifactDigest,holder:cfg.claim.holder,claimId:cfg.claim.claimId,phase:'deploy'});
   try{
    assertFacts();before();assertReleasePhase(phase);
    writeFileSync(dir+'/deploy-intent.json',JSON.stringify({...phase,state:'uncertain',reconcileRequired:true}),{flag:'wx',flush:true});
    const output=original(file,args,options);
    original(process.execPath,[dir+'/provider-readback.mjs','after'],{cwd:cfg.root,env:process.env,encoding:'utf8',stdio:['ignore','pipe','pipe']});
    finishReleasePhase(phase,{state:'completed',receiptRef:dir+'/deploy-after.json'});
    return output;
   }catch{
    const receipt=dir+'/deploy-uncertain.json';writeFileSync(receipt,JSON.stringify({...phase,state:'uncertain',reconcileRequired:true}),{flag:'wx',flush:true});
    finishReleasePhase(phase,{state:'uncertain',receiptRef:receipt});
    throw Error('DECODING_RELEASE_UNCERTAIN: reconcile the provider; do not replay this action');
   }
  }
  return original(file,args,options);
 };
 syncBuiltinESMExports();
 console.log('Exact source/artifact/provider/claim/phase guard enabled; product preflight remains unchanged.');
}

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/return-paths.spec.ts >> a cold page marks examples unavailable until their actions are ready
- Location: tests/e2e/return-paths.spec.ts:3:1

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator:  locator('.paste-surface input[type=file]').first()
Expected: disabled
Received: enabled
Timeout:  8000ms

Call log:
  - Expect "toBeDisabled" with timeout 8000ms
  - waiting for locator('.paste-surface input[type=file]').first()
    20 × locator resolved to <input type="file" accept="image/*" class="visually-hidden"/>
       - unexpected value "enabled"

```

```yaml
- button "사진·QR"
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test'
  2   | 
  3   | test('a cold page marks examples unavailable until their actions are ready', async ({ page }) => {
  4   |   let release!: () => void
  5   |   const ready = new Promise<void>((resolve) => {
  6   |     release = resolve
  7   |   })
  8   |   await page.route('**/_astro/*.js', async (route) => {
  9   |     await ready
  10  |     await route.continue()
  11  |   })
  12  |   // Module loading delays DOMContentLoaded; inspect SSR before releasing that load.
  13  |   await page.goto('/ko/', { waitUntil: 'commit' })
  14  |   await expect(page.locator('[data-sample-id="broken"]')).toBeDisabled()
> 15  |   await expect(page.locator('.paste-surface input[type=file]').first()).toBeDisabled()
      |                                                                         ^ Error: expect(locator).toBeDisabled() failed
  16  |   await expect(page.locator('.paste-surface input[type=file]').last()).toBeDisabled()
  17  |   await expect(page.locator('.paste-surface .input-actions > button')).toBeDisabled()
  18  |   release()
  19  |   await page.locator('[data-sample-id="broken"]').click()
  20  |   await expect(page.locator('.paste-surface input[type=file]').last()).toBeEnabled()
  21  |   await expect(page.locator('.answer-final .output-view')).toContainText('안녕하세요')
  22  | })
  23  | 
  24  | test('QR examples stay labelled and late generation cannot replace the visitor’s text', async ({
  25  |   page,
  26  | }) => {
  27  |   await page.addInitScript(() => {
  28  |     const toBlob = HTMLCanvasElement.prototype.toBlob
  29  |     HTMLCanvasElement.prototype.toBlob = function (callback, ...args) {
  30  |       return toBlob.call(
  31  |         this,
  32  |         (blob) => {
  33  |           setTimeout(() => callback(blob), 700)
  34  |         },
  35  |         ...args,
  36  |       )
  37  |     }
  38  |   })
  39  |   await page.goto('/ko/')
  40  |   await page.locator('[data-sample-id="qr"]').click()
  41  |   await expect(page.locator('.answer-final')).toBeVisible()
  42  |   await expect(page.locator('.example-context')).toBeVisible()
  43  |   await page.locator('[data-sample-id="qr"]').click()
  44  |   await page.locator('#decoder-input').fill(Buffer.from('내 글: 안녕하세요').toString('base64'))
  45  |   await expect(page.locator('.answer-final .output-view')).toContainText('내 글: 안녕하세요')
  46  |   await page.waitForTimeout(900) // Outlive the intentionally delayed QR generation.
  47  |   await expect(page.locator('.answer-final .output-view')).toContainText('내 글: 안녕하세요')
  48  |   await expect(page.locator('.example-context')).toHaveCount(0)
  49  | })
  50  | 
  51  | test('example becomes an empty focused input for the visitor’s own value', async ({ page }) => {
  52  |   await page.goto('/ko/fix-garbled-text/')
  53  |   await expect(page.locator('.answer-final .output-view')).not.toBeEmpty()
  54  |   await expect(page.locator('.example-context')).toContainText('예시')
  55  |   await page.locator('.example-context button').click()
  56  |   await expect(page.locator('#decoder-input')).toHaveValue('')
  57  |   await expect(page.locator('#decoder-input')).toBeFocused()
  58  |   await expect(page.locator('.example-context')).toHaveCount(0)
  59  |   await expect(page.locator('.answer-final')).toHaveCount(0)
  60  |   await page.locator('#decoder-input').fill(Buffer.from('내 값: 안녕하세요').toString('base64'))
  61  |   await expect(page.locator('.answer-final .output-view')).toContainText('내 값: 안녕하세요')
  62  |   await expect(page.locator('.example-context')).toHaveCount(0)
  63  | })
  64  | 
  65  | for (const failure of ['empty', 'throw']) {
  66  |   test(`failed QR generation (${failure}) never relabels a previous result`, async ({ page }) => {
  67  |     await page.addInitScript((mode) => {
  68  |       HTMLCanvasElement.prototype.toBlob = function (callback) {
  69  |         if (mode === 'throw') throw new Error('synthetic canvas failure')
  70  |         callback(null)
  71  |       }
  72  |     }, failure)
  73  |     await page.goto('/ko/')
  74  |     await page.locator('[data-sample-id="broken"]').click()
  75  |     await expect(page.locator('.answer-final .output-view')).toContainText('안녕하세요')
  76  |     await page.locator('[data-sample-id="qr"]').click()
  77  |     await expect(page.locator('.decoder-frame > .notice.warning')).toBeVisible()
  78  |     await expect(page.locator('.example-context')).toHaveCount(0)
  79  |     await expect(page.locator('.answer-final .output-view')).toContainText('안녕하세요')
  80  |   })
  81  | }
  82  | 
  83  | test('home connects all existing situational guides without changing the input URL', async ({
  84  |   page,
  85  | }) => {
  86  |   await page.goto('/ko/')
  87  |   await expect(page.locator('.task-guides a')).toHaveCount(8)
  88  |   await page.locator('[data-sample-id="broken"]').click()
  89  |   await expect(page.locator('.answer-final .output-view')).toContainText('안녕하세요')
  90  |   await expect(page.locator('.example-context')).toBeVisible()
  91  |   expect(new URL(page.url()).search).toBe('')
  92  |   await page.locator('.task-guides a[href="/ko/decode-mail-subject/"]').click()
  93  |   await expect(page.locator('.answer-final .output-view')).not.toBeEmpty()
  94  |   await expect(page.locator('.task-guides a')).toHaveCount(7)
  95  | })
  96  | 
  97  | test('all favorites survive reload and direct tool arrivals appear back at home', async ({
  98  |   page,
  99  | }) => {
  100 |   await page.goto('/ko/tools/')
  101 |   await expect(page.locator('.catalog-shell')).toHaveAttribute('data-hydrated', 'true')
  102 |   expect(
  103 |     await page.locator('input[type="search"]').evaluate((el) => el === document.activeElement),
  104 |   ).toBe(false)
  105 |   for (let i = 0; i < 15; i++) await page.locator('.favorite-button').nth(i).click()
  106 |   await page.reload()
  107 |   await expect(page.locator('section[aria-labelledby="favorite-tools"] a')).toHaveCount(15)
  108 |   await page.goto('/ko/json-format/')
  109 |   await expect
  110 |     .poll(() => page.evaluate(() => localStorage.getItem('decoding-recent-tools')))
  111 |     .toContain('json-format')
  112 |   await page.goto('/ko/')
  113 |   await expect(page.locator('.tool-shortcuts a[href="/ko/json-format/"]')).toBeVisible()
  114 |   await expect(page.locator('.tool-shortcuts .recent-links a')).not.toHaveCount(0)
  115 | })
```
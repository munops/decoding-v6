# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/return-paths.spec.ts >> typing before a situational page hydrates wins over its automatic example
- Location: tests/e2e/return-paths.spec.ts:263:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  locator('#decoder-input')
Expected: "=?UTF-8?B?7JWI64WV7ZWY7IS47JqU?="
Received: "=?UTF-8?B?7ZWc6riAIOygnOuqqQ==?="
Timeout:  8000ms

Call log:
  - Expect "toHaveValue" with timeout 8000ms
  - waiting for locator('#decoder-input')
    19 × locator resolved to <textarea id="decoder-input" spellcheck="false" autocomplete="off" autocapitalize="off" placeholder="여기를 눌러 붙여넣기"></textarea>
       - unexpected value "=?UTF-8?B?7ZWc6riAIOygnOuqqQ==?="

```

```yaml
- textbox "텍스트를 붙여넣거나 파일을 놓으세요":
  - /placeholder: 여기를 눌러 붙여넣기
  - text: =?UTF-8?B?7ZWc6riAIOygnOuqqQ==?=
```

# Test source

```ts
  179 | }) => {
  180 |   await page.goto('/ko/jwt-debugger/')
  181 |   await expect(page.locator('.jwt-verifier')).toBeVisible()
  182 |   await page.locator('.jwt-verifier summary').click()
  183 |   await expect(page.locator('.jwt-verifier textarea')).toBeVisible()
  184 |   const token = await page.locator('.operation-pane textarea').first().inputValue()
  185 |   await page.getByRole('button', { name: '이 토큰의 근거와 주의점 보기' }).click()
  186 |   await expect(page.locator('#decoder-input')).toHaveValue(token)
  187 |   await expect(page.locator('.answer-verdict')).toContainText('토큰')
  188 | })
  189 | 
  190 | test('an old JWT verification cannot validate a newly edited key', async ({ page }) => {
  191 |   await page.addInitScript(() => {
  192 |     const original = crypto.subtle.verify.bind(crypto.subtle)
  193 |     crypto.subtle.verify = async (...args: Parameters<SubtleCrypto['verify']>) => {
  194 |       const result = await original(...args)
  195 |       dispatchEvent(new Event('synthetic:verification-pending'))
  196 |       await new Promise((resolve) =>
  197 |         addEventListener('synthetic:release-verification', resolve, { once: true }),
  198 |       )
  199 |       return result
  200 |     }
  201 |   })
  202 |   const { createHmac } = await import('node:crypto')
  203 |   const key = 'synthetic-verification-key'
  204 |   const signing = `${Buffer.from('{"alg":"HS256"}').toString('base64url')}.${Buffer.from('{"sub":"test"}').toString('base64url')}`
  205 |   const token = `${signing}.${createHmac('sha256', key).update(signing).digest('base64url')}`
  206 |   await page.goto('/jwt-debugger/')
  207 |   await page.locator('.operation-pane textarea').first().fill(token)
  208 |   await page.locator('.jwt-verifier summary').click()
  209 |   await page.locator('.jwt-verifier textarea').fill(key)
  210 |   await page.evaluate(() =>
  211 |     addEventListener('synthetic:verification-pending', () => {
  212 |       document.documentElement.dataset.verificationPending = 'true'
  213 |     }),
  214 |   )
  215 |   await page.locator('.jwt-verifier button').click()
  216 |   await expect(page.locator('html')).toHaveAttribute('data-verification-pending', 'true')
  217 |   await page.locator('.jwt-verifier textarea').fill('different synthetic key')
  218 |   await page.evaluate(() => dispatchEvent(new Event('synthetic:release-verification')))
  219 |   await expect(page.locator('.jwt-verifier [role="status"]')).toBeEmpty()
  220 |   await expect(page.locator('.jwt-verifier button')).toBeEnabled()
  221 | })
  222 | 
  223 | test('situational input reaches copied text and lost input reaches honest recovery', async ({
  224 |   page,
  225 |   context,
  226 | }) => {
  227 |   await context.grantPermissions(['clipboard-read', 'clipboard-write'])
  228 |   for (const [route, input] of [
  229 |     ['/ko/decode-mail-subject/', '=?UTF-8?B?7JWI64WV7ZWY7IS47JqU?='],
  230 |     ['/ko/fix-garbled-text/', 'ì•ˆë…•í•˜ì„¸ìš”'],
  231 |   ]) {
  232 |     await page.goto(route!)
  233 |     await page.locator('#decoder-input').fill(input!)
  234 |     await expect(page.locator('.answer-final .output-view')).toHaveText('안녕하세요')
  235 |     await page.locator('.answer-final-heading button').click()
  236 |     expect(await page.evaluate(() => navigator.clipboard.readText())).toBe('안녕하세요')
  237 |   }
  238 |   await page.locator('#decoder-input').fill('����')
  239 |   await expect(page.locator('.answer-verdict')).toContainText('되돌릴 수 없어요')
  240 |   await page.locator('#decoder-input').fill('abcde')
  241 |   await expect(page.locator('.answer-card .next-step')).toContainText('원문을 끝까지 복사')
  242 | })
  243 | 
  244 | test('layer choices reflow at small widths and enlarged text', async ({ page }) => {
  245 |   for (const [width, textSize] of [
  246 |     [320, '100%'],
  247 |     [390, '200%'],
  248 |   ] as const) {
  249 |     await page.setViewportSize({ width, height: 844 })
  250 |     await page.goto('/ko/')
  251 |     await page.evaluate((size) => {
  252 |       document.documentElement.style.fontSize = size
  253 |     }, textSize)
  254 |     await page.locator('#decoder-input').fill('a2VlcC1teS10ZXh0')
  255 |     await expect(page.locator('.answer-final .output-view')).toHaveText('keep-my-text')
  256 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  257 |     for (const button of await page.locator('.result-layer-choices button').all()) {
  258 |       expect((await button.boundingBox())!.height).toBeGreaterThanOrEqual(44)
  259 |     }
  260 |   }
  261 | })
  262 | 
  263 | test('typing before a situational page hydrates wins over its automatic example', async ({
  264 |   page,
  265 | }) => {
  266 |   let release!: () => void
  267 |   const ready = new Promise<void>((resolve) => {
  268 |     release = resolve
  269 |   })
  270 |   await page.route('**/_astro/*.js', async (route) => {
  271 |     await ready
  272 |     await route.continue()
  273 |   })
  274 |   await page.goto('/ko/decode-mail-subject/', { waitUntil: 'commit' })
  275 |   const ownInput = '=?UTF-8?B?7JWI64WV7ZWY7IS47JqU?='
  276 |   await page.locator('#decoder-input').fill(ownInput)
  277 |   release()
  278 |   await expect(page.locator('[data-sample-id]:enabled').first()).toBeVisible()
> 279 |   await expect(page.locator('#decoder-input')).toHaveValue(ownInput)
      |                                                ^ Error: expect(locator).toHaveValue(expected) failed
  280 |   await expect(page.locator('.answer-final .output-view')).toHaveText('안녕하세요')
  281 |   await expect(page.locator('.example-context')).toHaveCount(0)
  282 | })
  283 | 
```
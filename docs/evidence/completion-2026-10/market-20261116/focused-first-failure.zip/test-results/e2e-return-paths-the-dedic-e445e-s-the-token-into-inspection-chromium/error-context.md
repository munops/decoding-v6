# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/return-paths.spec.ts >> the dedicated JWT tool verifies locally and carries the token into inspection
- Location: tests/e2e/return-paths.spec.ts:177:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.jwt-verifier')
Expected: visible
Timeout: 8000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 8000ms
  - waiting for locator('.jwt-verifier')

```

```yaml
- link "본문으로 건너뛰기":
  - /url: "#main"
- banner:
  - link "decod.ing 홈":
    - /url: /ko/
    - text: decod.ing
  - navigation "주 탐색":
    - link "풀기":
      - /url: /ko/
    - link "도구":
      - /url: /ko/tools/
    - link "넣어 둔 것":
      - /url: /ko/workspace/
    - link "더보기":
      - /url: /ko/more/
  - button "색상 테마 전환"
  - text: 기기에서만 처리
- main:
  - text: "404"
  - heading "이 주소에는 아무것도 없어요" [level=1]
  - paragraph: 아래에 값을 붙여넣거나 필요한 도구를 찾아보세요.
  - link "도구 찾기":
    - /url: /ko/tools/
  - region "범용 디코더":
    - link "내 기기 안에서만":
      - /url: /proof/
    - text: 텍스트를 붙여넣거나 파일을 놓으세요
    - button "지우기" [disabled]
    - textbox "텍스트를 붙여넣거나 파일을 놓으세요":
      - /placeholder: 여기를 눌러 붙여넣기
    - button "붙여넣기"
    - text: 사진·QR
    - button "사진·QR"
    - text: 파일 열기
    - button "파일 열기"
    - text: 최대 10 MiB
    - group: 복사 완료 알림
- contentinfo:
  - link "decod.ing":
    - /url: /ko/
  - paragraph: 모르는 글자를 이 기기 안에서 풀어요.
  - link "이 기기 데이터":
    - /url: /ko/data/
  - link "전송 직접 확인":
    - /url: /ko/proof/
  - link "Bookmarklet":
    - /url: /bookmarklet/
  - link "스폰서 안내":
    - /url: /sponsor/
  - link "49 도구":
    - /url: /ko/tools/
  - link "개인정보 보호":
    - /url: /ko/privacy/
  - link "이용약관":
    - /url: /ko/terms/
  - link "문의":
    - /url: /ko/support/
  - link "감지 기준":
    - /url: /ko/methodology/
  - link "데스크톱":
    - /url: /download/
  - link "변경 기록":
    - /url: /changelog/
  - link "소개":
    - /url: /ko/about/
  - paragraph: 계정, 업로드, 생성형 AI, 추적 광고가 없습니다. MUNOPS (문옵스) · Build d54465d · 63 formats
  - checkbox "동작 횟수만 세기" [checked]
  - text: 동작 횟수만 세기
```

# Test source

```ts
  81  | }) => {
  82  |   await page.goto('/ko/')
  83  |   await expect(page.locator('.task-guides a')).toHaveCount(8)
  84  |   await page.locator('[data-sample-id="broken"]').click()
  85  |   await expect(page.locator('.answer-final .output-view')).toContainText('안녕하세요')
  86  |   await expect(page.locator('.example-context')).toBeVisible()
  87  |   expect(new URL(page.url()).search).toBe('')
  88  |   await page.locator('.task-guides a[href="/ko/decode-mail-subject/"]').click()
  89  |   await expect(page.locator('.answer-final .output-view')).not.toBeEmpty()
  90  |   await expect(page.locator('.task-guides a')).toHaveCount(7)
  91  | })
  92  | 
  93  | test('all favorites survive reload and direct tool arrivals appear back at home', async ({
  94  |   page,
  95  | }) => {
  96  |   await page.goto('/ko/tools/')
  97  |   await expect(page.locator('.catalog-shell')).toHaveAttribute('data-hydrated', 'true')
  98  |   expect(
  99  |     await page.locator('input[type="search"]').evaluate((el) => el === document.activeElement),
  100 |   ).toBe(false)
  101 |   for (let i = 0; i < 15; i++) await page.locator('.favorite-button').nth(i).click()
  102 |   await page.reload()
  103 |   await expect(page.locator('section[aria-labelledby="favorite-tools"] a')).toHaveCount(15)
  104 |   await page.goto('/ko/json-format/')
  105 |   await expect
  106 |     .poll(() => page.evaluate(() => localStorage.getItem('decoding-recent-tools')))
  107 |     .toContain('json-format')
  108 |   await page.goto('/ko/')
  109 |   await expect(page.locator('.tool-shortcuts a[href="/ko/json-format/"]')).toBeVisible()
  110 |   await expect(page.locator('.tool-shortcuts .recent-links a')).not.toHaveCount(0)
  111 | })
  112 | 
  113 | test('denied preference storage does not break starring or using a tool', async ({ page }) => {
  114 |   const errors: string[] = []
  115 |   page.on('pageerror', (error) => errors.push(error.message))
  116 |   await page.addInitScript(() => {
  117 |     Storage.prototype.setItem = () => {
  118 |       throw new DOMException('denied', 'SecurityError')
  119 |     }
  120 |   })
  121 |   await page.goto('/ko/tools/')
  122 |   await page.locator('.favorite-button').first().click()
  123 |   await expect(page.locator('.favorite-button').first()).toHaveAttribute('aria-pressed', 'true')
  124 |   await expect(
  125 |     page.getByRole('status').filter({ hasText: '설정을 저장하지 못했어요' }),
  126 |   ).toBeVisible()
  127 |   await page.goto('/ko/json-format/')
  128 |   await expect(
  129 |     page.locator('.notice').filter({ hasText: '설정을 저장하지 못했어요' }),
  130 |   ).toBeVisible()
  131 |   await expect(page.locator('.tool-workbench')).toBeVisible()
  132 |   expect(errors).toEqual([])
  133 | })
  134 | 
  135 | test('recommended readable output and every explicit layer choice use the same copy target', async ({
  136 |   page,
  137 |   context,
  138 | }) => {
  139 |   await context.grantPermissions(['clipboard-read', 'clipboard-write'])
  140 |   await page.goto('/ko/')
  141 |   await page.locator('#decoder-input').fill('a2VlcC1teS10ZXh0')
  142 |   const output = page.locator('.answer-final .output-view')
  143 |   await expect(output).toHaveText('keep-my-text')
  144 |   await expect(page.locator('.answer-verdict')).not.toContainText('2겹')
  145 |   await page.locator('.answer-final-heading button').click()
  146 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe('keep-my-text')
  147 |   await page.locator('.result-layer-choices button').nth(1).click()
  148 |   await expect(output).toHaveText('91 e7 a9 fa 6c be b5 ec 6d')
  149 |   await expect(page.locator('.answer-verdict')).toContainText('2겹')
  150 |   await page.locator('.answer-final-heading button').click()
  151 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(
  152 |     '91 e7 a9 fa 6c be b5 ec 6d',
  153 |   )
  154 |   await page.locator('.result-layer-choices button').first().click()
  155 |   await expect(output).toHaveText('keep-my-text')
  156 | })
  157 | 
  158 | test('automatic and clicked examples never consume a visitor’s decode completion count', async ({
  159 |   page,
  160 | }) => {
  161 |   const names: string[] = []
  162 |   await page.route('**/e/events', async (route) => {
  163 |     names.push(JSON.parse(route.request().postData() ?? '{}').name)
  164 |     await route.fulfill({ status: 204 })
  165 |   })
  166 |   await page.goto('/ko/decode-mail-subject/')
  167 |   await expect(page.locator('.answer-final')).toBeVisible()
  168 |   await page.locator('.triage-sample').first().click()
  169 |   await expect(page.locator('.answer-final')).toBeVisible()
  170 |   expect(names).not.toContain('decode_completed')
  171 |   await page.locator('.example-context button').click()
  172 |   await page.locator('#decoder-input').fill(Buffer.from('내 메일 제목').toString('base64'))
  173 |   await expect(page.locator('.answer-final .output-view')).toHaveText('내 메일 제목')
  174 |   await expect.poll(() => names.includes('decode_completed')).toBe(true)
  175 | })
  176 | 
  177 | test('the dedicated JWT tool verifies locally and carries the token into inspection', async ({
  178 |   page,
  179 | }) => {
  180 |   await page.goto('/ko/tools/jwt-debugger/')
> 181 |   await expect(page.locator('.jwt-verifier')).toBeVisible()
      |                                               ^ Error: expect(locator).toBeVisible() failed
  182 |   await page.locator('.jwt-verifier summary').click()
  183 |   await expect(page.locator('.jwt-verifier textarea')).toBeVisible()
  184 |   const token = await page.locator('.operation-pane textarea').first().inputValue()
  185 |   await page.getByRole('button', { name: '이 토큰의 근거와 주의점 보기' }).click()
  186 |   await expect(page.locator('#decoder-input')).toHaveValue(token)
  187 |   await expect(page.locator('.answer-verdict')).toContainText('토큰')
  188 | })
  189 | 
  190 | test('an old JWT verification cannot validate a newly edited key', async ({ page }) => {
  191 |   await page.addInitScript(() => {
  192 |     const original = crypto.subtle.verify.bind(crypto.subtle)
  193 |     crypto.subtle.verify = async (...args: Parameters<SubtleCrypto['verify']>) => {
  194 |       const result = await original(...args)
  195 |       dispatchEvent(new Event('synthetic:verification-pending'))
  196 |       await new Promise((resolve) =>
  197 |         addEventListener('synthetic:release-verification', resolve, { once: true }),
  198 |       )
  199 |       return result
  200 |     }
  201 |   })
  202 |   const { createHmac } = await import('node:crypto')
  203 |   const key = 'synthetic-verification-key'
  204 |   const signing = `${Buffer.from('{"alg":"HS256"}').toString('base64url')}.${Buffer.from('{"sub":"test"}').toString('base64url')}`
  205 |   const token = `${signing}.${createHmac('sha256', key).update(signing).digest('base64url')}`
  206 |   await page.goto('/tools/jwt-debugger/')
  207 |   await page.locator('.operation-pane textarea').first().fill(token)
  208 |   await page.locator('.jwt-verifier summary').click()
  209 |   await page.locator('.jwt-verifier textarea').fill(key)
  210 |   await page.evaluate(() =>
  211 |     addEventListener('synthetic:verification-pending', () => {
  212 |       document.documentElement.dataset.verificationPending = 'true'
  213 |     }),
  214 |   )
  215 |   await page.locator('.jwt-verifier button').click()
  216 |   await expect(page.locator('html')).toHaveAttribute('data-verification-pending', 'true')
  217 |   await page.locator('.jwt-verifier textarea').fill('different synthetic key')
  218 |   await page.evaluate(() => dispatchEvent(new Event('synthetic:release-verification')))
  219 |   await expect(page.locator('.jwt-verifier [role="status"]')).toBeEmpty()
  220 |   await expect(page.locator('.jwt-verifier button')).toBeEnabled()
  221 | })
  222 | 
```
import { readFileSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { assertClaimsFreshReadOnly } from '../../../scripts/lib/work-claims.mjs';
import { validateReleaseWaveFile } from '../../../scripts/check-release-wave.mjs';
import { reserveReleasePhase, assertReleasePhase, finishReleasePhase } from '../../../scripts/lib/release-phase-reservation.mjs';
const root='/Users/minhan/workspace/decoding-v6',dir=root+'/.local-release-artifacts/decoding-market-20261116';
const cfg=JSON.parse(readFileSync(dir+'/evidence-sync.json')),release=JSON.parse(readFileSync(root+'/docs/evidence/completion-2026-10/market-20261116/release.json'));
const git=args=>execFileSync('git',args,{cwd:root,encoding:'utf8',stdio:['ignore','pipe','pipe'],maxBuffer:64*1024*1024}).trim();
const executor=git(['rev-parse','HEAD']);
const health=async()=>{for(const origin of ['https://decod.ing','https://www.decod.ing','https://decoding-v6.wjstks3474.workers.dev']){const r=await fetch(origin+'/healthz',{signal:AbortSignal.timeout(15000)}),b=await r.json();if(!r.ok||!b.ok||b.revision!==release.runtimeSource)throw Error('live runtime drift');}};
async function facts(){
 if(git(['rev-parse','HEAD'])!==executor||git(['status','--porcelain=v1','--untracked-files=all']))throw Error('unclean evidence source');
 if(git(['ls-remote','origin','refs/heads/main']).split(/\s+/)[0]!==cfg.before)throw Error('remote drift');
 if(git(['diff','--name-only',cfg.before+'..'+cfg.source]).split('\n').some(p=>!p.startsWith('docs/')))throw Error('non-document change');
 if(git(['diff','--name-only',cfg.source+'..'+executor]).split('\n').filter(Boolean).some(p=>p!==cfg.ref))throw Error('evidence packet drift');
 const diff=execFileSync('git',['diff','--binary',cfg.before+'..'+cfg.source],{cwd:root,maxBuffer:64*1024*1024});if(createHash('sha256').update(diff).digest('hex')!==cfg.digest)throw Error('evidence artifact drift');
 if(validateReleaseWaveFile(root+'/'+cfg.ref,{requireCurrentAuthorization:true}).length)throw Error('invalid evidence wave');
 assertClaimsFreshReadOnly([cfg.claim],{lane:'owner_lane',mutationModes:true});await health();
}
await facts();const phase=reserveReleasePhase({waveId:cfg.id,actionId:cfg.id,resource:'provider:github:munops/decoding-v6',sourceRevision:cfg.source,artifactDigest:cfg.digest,holder:cfg.claim.holder,claimId:cfg.claim.claimId,phase:'push'});
try{await facts();assertReleasePhase(phase);writeFileSync(dir+'/evidence-push-intent.json',JSON.stringify({...phase,state:'uncertain',reconcileRequired:true}),{flag:'wx',flush:true});git(['push','origin','HEAD:refs/heads/main']);const remote=git(['ls-remote','origin','refs/heads/main']).split(/\s+/)[0];if(remote!==executor)throw Error('source readback mismatch');await health();const receipt={checkedAt:new Date().toISOString(),state:'verified',sourceRevision:cfg.source,pushedHead:remote,runtimeSource:release.runtimeSource,runtimeRedeployed:false,force:false,visibilityChanged:false};writeFileSync(dir+'/evidence-push-after.json',JSON.stringify(receipt,null,2),{flag:'wx',flush:true});finishReleasePhase(phase,{state:'completed',receiptRef:dir+'/evidence-push-after.json'});console.log(receipt);}catch{writeFileSync(dir+'/evidence-push-uncertain.json',JSON.stringify({...phase,state:'uncertain',reconcileRequired:true}),{flag:'wx',flush:true});finishReleasePhase(phase,{state:'uncertain',receiptRef:dir+'/evidence-push-uncertain.json'});throw Error('Evidence publication uncertain; reconcile before replay');}

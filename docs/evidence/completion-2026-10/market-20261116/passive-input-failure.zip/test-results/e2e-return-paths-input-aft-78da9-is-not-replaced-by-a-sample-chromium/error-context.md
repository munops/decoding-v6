# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/return-paths.spec.ts >> input after hydration commits but before passive startup effects is not replaced by a sample
- Location: tests/e2e/return-paths.spec.ts:329:1

# Error details

```
Error: expect(locator).toHaveValue(expected) failed

Locator:  locator('#decoder-input')
Expected: "7LSI6riwIO2ZlOuptOyXkOyEnCDrgrTqsIAg67aZ7J24IOq4gA=="
Received: "=?UTF-8?B?7ZWc6riAIOygnOuqqQ==?="
Timeout:  8000ms

Call log:
  - Expect "toHaveValue" with timeout 8000ms
  - waiting for locator('#decoder-input')
    20 × locator resolved to <textarea id="decoder-input" spellcheck="false" autocomplete="off" autocapitalize="off" placeholder="여기를 눌러 붙여넣기"></textarea>
       - unexpected value "=?UTF-8?B?7ZWc6riAIOygnOuqqQ==?="

```

```yaml
- textbox "텍스트를 붙여넣거나 파일을 놓으세요":
  - /placeholder: 여기를 눌러 붙여넣기
  - text: =?UTF-8?B?7ZWc6riAIOygnOuqqQ==?=
```

# Test source

```ts
  259 |     await expect(page.locator('.answer-final .output-view')).toHaveText('keep-my-text')
  260 |     expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  261 |     for (const button of await page.locator('.result-layer-choices button').all()) {
  262 |       expect((await button.boundingBox())!.height).toBeGreaterThanOrEqual(44)
  263 |     }
  264 |   }
  265 | })
  266 | 
  267 | test('typing before a situational page hydrates wins over its automatic example', async ({
  268 |   page,
  269 | }) => {
  270 |   let release!: () => void
  271 |   const ready = new Promise<void>((resolve) => {
  272 |     release = resolve
  273 |   })
  274 |   await page.route('**/_astro/*.js', async (route) => {
  275 |     await ready
  276 |     await route.continue()
  277 |   })
  278 |   await page.goto('/ko/decode-mail-subject/', { waitUntil: 'commit' })
  279 |   const ownInput = '=?UTF-8?B?7JWI64WV7ZWY7IS47JqU?='
  280 |   await page.locator('#decoder-input').fill(ownInput)
  281 |   release()
  282 |   await expect(page.locator('[data-sample-id]:enabled').first()).toBeVisible()
  283 |   await expect(page.locator('#decoder-input')).toHaveValue(ownInput)
  284 |   await expect(page.locator('.answer-final .output-view')).toHaveText('안녕하세요')
  285 |   await expect(page.locator('.example-context')).toHaveCount(0)
  286 | })
  287 | 
  288 | test('retry restores the latest situational input and clear restart never replays an example', async ({
  289 |   page,
  290 | }) => {
  291 |   await page.addInitScript(() => {
  292 |     const NativeWorker = window.Worker
  293 |     class FaultWorker extends NativeWorker {
  294 |       constructor(url: string | URL, options?: WorkerOptions) {
  295 |         super(url, options)
  296 |         if (String(url).includes('decoder.worker'))
  297 |           this.addEventListener('message', (event) => {
  298 |             if (document.documentElement.dataset.failNext === 'true' && event.data.result) {
  299 |               document.documentElement.dataset.failNext = 'false'
  300 |               event.data.result.root.selected.evidence = null
  301 |             }
  302 |           })
  303 |       }
  304 |     }
  305 |     window.Worker = FaultWorker
  306 |   })
  307 |   await page.goto('/ko/decode-mail-subject/')
  308 |   await expect(page.locator('.answer-final')).toBeVisible()
  309 |   const input = Buffer.from('내가 복구할 최근 입력').toString('base64')
  310 |   await page.evaluate(() => {
  311 |     document.documentElement.dataset.failNext = 'true'
  312 |   })
  313 |   await page.locator('#decoder-input').fill(input)
  314 |   await expect(page.getByRole('alert')).toBeVisible()
  315 |   await page.getByRole('button', { name: '다시 시도', exact: true }).click()
  316 |   await expect(page.locator('#decoder-input')).toHaveValue(input)
  317 |   await expect(page.locator('.answer-final .output-view')).toHaveText('내가 복구할 최근 입력')
  318 |   await page.evaluate(() => {
  319 |     document.documentElement.dataset.failNext = 'true'
  320 |   })
  321 |   await page.locator('#decoder-input').fill(Buffer.from('또 다른 내 입력').toString('base64'))
  322 |   await expect(page.getByRole('alert')).toBeVisible()
  323 |   await page.getByRole('alert').getByRole('button').nth(1).click()
  324 |   await expect(page.locator('#decoder-input')).toHaveValue('')
  325 |   await expect(page.locator('.example-context')).toHaveCount(0)
  326 |   await expect(page.locator('.answer-final')).toHaveCount(0)
  327 | })
  328 | 
  329 | test('input after hydration commits but before passive startup effects is not replaced by a sample', async ({
  330 |   page,
  331 | }) => {
  332 |   const ownInput = Buffer.from('초기 화면에서 내가 붙인 글').toString('base64')
  333 |   await page.addInitScript((value) => {
  334 |     const observer = new MutationObserver((records) => {
  335 |       for (const record of records) {
  336 |         const island = record.target
  337 |         if (
  338 |           !(island instanceof HTMLElement) ||
  339 |           island.tagName !== 'ASTRO-ISLAND' ||
  340 |           island.hasAttribute('ssr')
  341 |         )
  342 |           continue
  343 |         const input = island.querySelector<HTMLTextAreaElement>('#decoder-input')
  344 |         if (!input) continue
  345 |         observer.disconnect()
  346 |         input.value = value
  347 |         input.dispatchEvent(
  348 |           new InputEvent('input', { bubbles: true, inputType: 'insertFromPaste' }),
  349 |         )
  350 |         document.documentElement.dataset.injectedBeforeStartup = 'true'
  351 |         break
  352 |       }
  353 |     })
  354 |     observer.observe(document, { subtree: true, attributes: true, attributeFilter: ['ssr'] })
  355 |   }, ownInput)
  356 |   await page.goto('/ko/decode-mail-subject/')
  357 |   await expect(page.locator('html')).toHaveAttribute('data-injected-before-startup', 'true')
  358 |   await expect(page.locator('[data-sample-id]:enabled').first()).toBeVisible()
> 359 |   await expect(page.locator('#decoder-input')).toHaveValue(ownInput)
      |                                                ^ Error: expect(locator).toHaveValue(expected) failed
  360 |   await expect(page.locator('.answer-final .output-view')).toHaveText('초기 화면에서 내가 붙인 글')
  361 |   await expect(page.locator('.example-context')).toHaveCount(0)
  362 | })
  363 | 
```
import { spawn } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
const dir='/Users/minhan/workspace/decoding-v6/.wrangler/decoding-market-20261116';
const after=JSON.parse(readFileSync(dir+'/deploy-after.json'));
const version=after.deployment.versions[0].version_id;
const startedAt=new Date().toISOString();
const child=spawn('pnpm',['exec','wrangler','tail','decoding-v6','--format','json','--ip','self','--version-id',version],{cwd:'/Users/minhan/workspace/decoding-v6',detached:true,stdio:['ignore','pipe','pipe'],env:{...process.env,CLOUDFLARE_ACCOUNT_ID:'69abd904cab5ffd103e569e7e050a884',WRANGLER_WRITE_LOGS:'false',WRANGLER_SEND_METRICS:'false'}});
let json='',depth=0,quoted=false,escaped=false,stderrBytes=0;
const rows=[];
child.stdout.on('data',chunk=>{for(const char of chunk.toString()){
 if(!depth&&char!=='{')continue;
 json+=char;
 if(quoted){if(escaped)escaped=false;else if(char==='\\')escaped=true;else if(char==='"')quoted=false;}
 else if(char==='"')quoted=true;else if(char==='{')depth++;else if(char==='}')depth--;
 if(json.length>1024*1024){json='';depth=0;quoted=false;escaped=false;continue;}
 if(!depth){try{const event=JSON.parse(json);rows.push({outcome:['ok','exception','exceededCpu','exceededMemory','canceled'].includes(event.outcome)?event.outcome:'unknown',exceptions:Array.isArray(event.exceptions)?event.exceptions.length:0,status:typeof event.event?.response?.status==='number'?event.event.response.status:null});}catch{}json='';}
}});
child.stderr.on('data',chunk=>{stderrBytes+=chunk.length;});
const requests=setTimeout(()=>{void Promise.allSettled([1,2,3].map(()=>fetch('https://decod.ing/healthz',{signal:AbortSignal.timeout(10000)})));},7000);
const stop=setTimeout(()=>{try{process.kill(-child.pid,'SIGINT');}catch{}},25000);
const force=setTimeout(()=>{try{process.kill(-child.pid,'SIGTERM');}catch{}},28000);
const result=await new Promise(resolve=>{child.on('error',()=>resolve({code:null,spawnFailed:true}));child.on('close',(code,signal)=>resolve({code,signal}));});
clearTimeout(requests);clearTimeout(stop);clearTimeout(force);
const receipt={startedAt,finishedAt:new Date().toISOString(),version,selfIpFilter:true,rawRequestsOrMessagesStored:false,rows,status:rows.length?(rows.every(r=>r.outcome==='ok'&&!r.exceptions)?'sampled_current_requests_ok':'sampled_error_or_unknown'):'no_matching_samples',stderrBytes,process:result};writeFileSync(dir+'/tail-observation.json',JSON.stringify(receipt,null,2));console.log({status:receipt.status,samples:rows.length});

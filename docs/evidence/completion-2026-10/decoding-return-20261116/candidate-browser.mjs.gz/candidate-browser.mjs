import { chromium } from '@playwright/test';
import { writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
const root='/Users/minhan/workspace/decoding-v6',dir=root+'/.wrangler/decoding-return-20261116';
const source=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
const browser=await chromium.launch({headless:true}),results=[];
try {
 for(const locale of ['en','ko']) {
  const context=await browser.newContext({locale:'en-US',serviceWorkers:'block',viewport:{width:1440,height:900},colorScheme:'light',reducedMotion:'reduce'}),p=await context.newPage();
  await p.goto('http://127.0.0.1:4322'+(locale==='ko'?'/ko/':'/'));
  await p.locator('[data-sample-id="broken"]:enabled').waitFor();
  for(const width of [1440,390,320]) {
   await p.setViewportSize({width,height:900});
   const r=await p.evaluate(()=>({path:location.pathname,lang:document.documentElement.lang,width:innerWidth,overflow:document.documentElement.scrollWidth-innerWidth,source:document.querySelector('meta[name="application-build"]').content,guides:document.querySelectorAll('.guide-links a').length,smallTargets:[...document.querySelectorAll('.guide-links a')].filter(el=>el.getBoundingClientRect().height<44).length}));
   if(r.source!==source||r.lang!==locale||r.overflow||r.guides!==8||r.smallTargets)throw Error(JSON.stringify(r));results.push(r);
   if(locale==='ko'&&width===390){await p.locator('.task-guides').scrollIntoViewIfNeeded();await p.screenshot({path:dir+'/guides-390.png'});}
  }
  if(locale==='ko') {
   await p.evaluate(()=>document.documentElement.style.fontSize='200%');
   const r=await p.evaluate(()=>({width:innerWidth,rootFont:getComputedStyle(document.documentElement).fontSize,overflow:document.documentElement.scrollWidth-innerWidth}));if(r.rootFont!=='32px'||r.overflow)throw Error('200% reflow');results.push(r);
   await p.locator('.task-guides').scrollIntoViewIfNeeded();await p.screenshot({path:dir+'/guides-320-200.png'});
   await p.evaluate(()=>document.documentElement.style.fontSize='');await p.setViewportSize({width:390,height:844});await p.locator('[data-sample-id="broken"]').click();await p.locator('.answer-final .output-view').filter({hasText:'안녕하세요'}).waitFor();await p.locator('.example-context').scrollIntoViewIfNeeded();await p.screenshot({path:dir+'/example-390.png'});
  }
  await context.close();
 }
 const receipt={checkedAt:new Date().toISOString(),sourceRevision:source,target:'http://127.0.0.1:4322',freshProductionPreview:true,cleanContexts:true,serviceWorkers:'block',results};writeFileSync(dir+'/candidate-capture.json',JSON.stringify(receipt));console.log(receipt);
}finally{await browser.close()}

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/product.spec.ts >> command palette focus, favorites, and recent tools store slugs only
- Location: tests/e2e/product.spec.ts:139:1

# Error details

```
Error: locator.click: Error: strict mode violation: getByRole('link', { name: /JSON Format \/ Validate/ }) resolved to 2 elements:
    1) <a href="/json-format/">JSON Format / Validate</a> aka getByRole('link', { name: 'JSON Format / Validate', exact: true })
    2) <a href="/json-format/" class="tool-card-link">…</a> aka getByRole('link', { name: 'JSON Format / Validate Format' })

Call log:
  - waiting for getByRole('link', { name: /JSON Format \/ Validate/ })

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - link "Skip to content" [ref=e2] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=e3]:
    - link "decod.ing home" [ref=e4] [cursor=pointer]:
      - /url: /
      - img [ref=e5]
      - generic [ref=e10]: decod.ing
    - navigation "Primary" [ref=e11]:
      - link "Decode" [ref=e12] [cursor=pointer]:
        - /url: /
      - link "Tools" [ref=e13] [cursor=pointer]:
        - /url: /tools/
      - link "Saved" [ref=e14] [cursor=pointer]:
        - /url: /workspace/
      - link "More" [ref=e15] [cursor=pointer]:
        - /url: /more/
    - group [ref=e16]:
      - generic "Language" [ref=e17] [cursor=pointer]: English
    - button "Toggle color theme" [ref=e18] [cursor=pointer]:
      - img [ref=e19]
    - generic [ref=e23]: Local only
  - main [ref=e25]:
    - paragraph [ref=e26]:
      - link "If you do not know what it is, paste it into the decoder." [ref=e27] [cursor=pointer]:
        - /url: /
    - generic [ref=e28]:
      - generic [ref=e29]: Tools
      - heading "49 tools. One private workbench." [level=1] [ref=e30]
      - paragraph [ref=e31]: Every tool runs on this device. Heavy parsers load only when you open them.
    - generic [ref=e34]:
      - generic [ref=e35]:
        - generic [ref=e36]: Search all 49 local tools
        - searchbox "Search all 49 local tools" [ref=e37]
      - paragraph [ref=e38]: 49 of 49 tools
      - region "Favorite tools" [ref=e39]:
        - heading "Favorite tools" [level=2] [ref=e41]
        - link "JSON Format / Validate" [ref=e43] [cursor=pointer]:
          - /url: /json-format/
      - region "Format" [ref=e44]:
        - generic [ref=e45]:
          - generic [ref=e46]: Category
          - heading "Format" [level=2] [ref=e47]
        - generic [ref=e48]:
          - article [ref=e49]:
            - generic [ref=e50]:
              - generic [ref=e51]: "{ }"
              - 'button "Remove from favorites: JSON Format / Validate" [active] [pressed] [ref=e53] [cursor=pointer]': ★
            - link "JSON Format / Validate Format, minify, and validate JSON. Open tool →" [ref=e54] [cursor=pointer]:
              - /url: /json-format/
              - heading "JSON Format / Validate" [level=3] [ref=e55]
              - paragraph [ref=e56]: Format, minify, and validate JSON.
              - generic [ref=e57]: Open tool →
          - article [ref=e58]:
            - generic [ref=e59]:
              - generic [ref=e60]: "{ }"
              - 'button "Add to favorites: HTML Beautify / Minify" [ref=e62] [cursor=pointer]': ☆
            - link "HTML Beautify / Minify Format or minify HTML without executing it. Open tool →" [ref=e63] [cursor=pointer]:
              - /url: /html-format/
              - heading "HTML Beautify / Minify" [level=3] [ref=e64]
              - paragraph [ref=e65]: Format or minify HTML without executing it.
              - generic [ref=e66]: Open tool →
          - article [ref=e67]:
            - generic [ref=e68]:
              - generic [ref=e69]: "{ }"
              - 'button "Add to favorites: CSS Beautify / Minify" [ref=e71] [cursor=pointer]': ☆
            - link "CSS Beautify / Minify Format or minify CSS. Open tool →" [ref=e72] [cursor=pointer]:
              - /url: /css-format/
              - heading "CSS Beautify / Minify" [level=3] [ref=e73]
              - paragraph [ref=e74]: Format or minify CSS.
              - generic [ref=e75]: Open tool →
          - article [ref=e76]:
            - generic [ref=e77]:
              - generic [ref=e78]: "{ }"
              - 'button "Add to favorites: JavaScript Beautify / Minify" [ref=e80] [cursor=pointer]': ☆
            - link "JavaScript Beautify / Minify Format JavaScript source as text. Open tool →" [ref=e81] [cursor=pointer]:
              - /url: /javascript-format/
              - heading "JavaScript Beautify / Minify" [level=3] [ref=e82]
              - paragraph [ref=e83]: Format JavaScript source as text.
              - generic [ref=e84]: Open tool →
          - article [ref=e85]:
            - generic [ref=e86]:
              - generic [ref=e87]: "{ }"
              - 'button "Add to favorites: ERB Beautify / Minify" [ref=e89] [cursor=pointer]': ☆
            - link "ERB Beautify / Minify Indent ERB markup without executing templates. Open tool →" [ref=e90] [cursor=pointer]:
              - /url: /erb-format/
              - heading "ERB Beautify / Minify" [level=3] [ref=e91]
              - paragraph [ref=e92]: Indent ERB markup without executing templates.
              - generic [ref=e93]: Open tool →
          - article [ref=e94]:
            - generic [ref=e95]:
              - generic [ref=e96]: "{ }"
              - 'button "Add to favorites: LESS Beautify / Minify" [ref=e98] [cursor=pointer]': ☆
            - link "LESS Beautify / Minify Format LESS source without compiling it. Open tool →" [ref=e99] [cursor=pointer]:
              - /url: /less-format/
              - heading "LESS Beautify / Minify" [level=3] [ref=e100]
              - paragraph [ref=e101]: Format LESS source without compiling it.
              - generic [ref=e102]: Open tool →
          - article [ref=e103]:
            - generic [ref=e104]:
              - generic [ref=e105]: "{ }"
              - 'button "Add to favorites: SCSS Beautify / Minify" [ref=e107] [cursor=pointer]': ☆
            - link "SCSS Beautify / Minify Format SCSS source without compiling it. Open tool →" [ref=e108] [cursor=pointer]:
              - /url: /scss-format/
              - heading "SCSS Beautify / Minify" [level=3] [ref=e109]
              - paragraph [ref=e110]: Format SCSS source without compiling it.
              - generic [ref=e111]: Open tool →
          - article [ref=e112]:
            - generic [ref=e113]:
              - generic [ref=e114]: "{ }"
              - 'button "Add to favorites: XML Beautify / Minify" [ref=e116] [cursor=pointer]': ☆
            - link "XML Beautify / Minify Format or minify XML as inert text. Open tool →" [ref=e117] [cursor=pointer]:
              - /url: /xml-format/
              - heading "XML Beautify / Minify" [level=3] [ref=e118]
              - paragraph [ref=e119]: Format or minify XML as inert text.
              - generic [ref=e120]: Open tool →
          - article [ref=e121]:
            - generic [ref=e122]:
              - generic [ref=e123]: "{ }"
              - 'button "Add to favorites: SQL Formatter" [ref=e125] [cursor=pointer]': ☆
            - link "SQL Formatter Format SQL with an explicit dialect. Open tool →" [ref=e126] [cursor=pointer]:
              - /url: /sql-format/
              - heading "SQL Formatter" [level=3] [ref=e127]
              - paragraph [ref=e128]: Format SQL with an explicit dialect.
              - generic [ref=e129]: Open tool →
          - article [ref=e130]:
            - generic [ref=e131]:
              - generic [ref=e132]: "{ }"
              - 'button "Add to favorites: Line Sort / Dedupe" [ref=e134] [cursor=pointer]': ☆
            - link "Line Sort / Dedupe Sort lines and optionally remove duplicates. Open tool →" [ref=e135] [cursor=pointer]:
              - /url: /line-sort/
              - heading "Line Sort / Dedupe" [level=3] [ref=e136]
              - paragraph [ref=e137]: Sort lines and optionally remove duplicates.
              - generic [ref=e138]: Open tool →
      - region "Convert" [ref=e139]:
        - generic [ref=e140]:
          - generic [ref=e141]: Category
          - heading "Convert" [level=2] [ref=e142]
        - generic [ref=e143]:
          - article [ref=e144]:
            - generic [ref=e145]:
              - generic [ref=e146]: ↔
              - 'button "Add to favorites: URL Parser" [ref=e148] [cursor=pointer]': ☆
            - link "URL Parser Inspect URL components and query parameters. Open tool →" [ref=e149] [cursor=pointer]:
              - /url: /url-parser/
              - heading "URL Parser" [level=3] [ref=e150]
              - paragraph [ref=e151]: Inspect URL components and query parameters.
              - generic [ref=e152]: Open tool →
          - article [ref=e153]:
            - generic [ref=e154]:
              - generic [ref=e155]: ↔
              - 'button "Add to favorites: YAML to JSON" [ref=e157] [cursor=pointer]': ☆
            - link "YAML to JSON Convert YAML to JSON. Open tool →" [ref=e158] [cursor=pointer]:
              - /url: /yaml-to-json/
              - heading "YAML to JSON" [level=3] [ref=e159]
              - paragraph [ref=e160]: Convert YAML to JSON.
              - generic [ref=e161]: Open tool →
          - article [ref=e162]:
            - generic [ref=e163]:
              - generic [ref=e164]: ↔
              - 'button "Add to favorites: JSON to YAML" [ref=e166] [cursor=pointer]': ☆
            - link "JSON to YAML Convert JSON to YAML. Open tool →" [ref=e167] [cursor=pointer]:
              - /url: /json-to-yaml/
              - heading "JSON to YAML" [level=3] [ref=e168]
              - paragraph [ref=e169]: Convert JSON to YAML.
              - generic [ref=e170]: Open tool →
          - article [ref=e171]:
            - generic [ref=e172]:
              - generic [ref=e173]: ↔
              - 'button "Add to favorites: Number Base Converter" [ref=e175] [cursor=pointer]': ☆
            - link "Number Base Converter Convert integers between bases 2 and 36. Open tool →" [ref=e176] [cursor=pointer]:
              - /url: /number-base/
              - heading "Number Base Converter" [level=3] [ref=e177]
              - paragraph [ref=e178]: Convert integers between bases 2 and 36.
              - generic [ref=e179]: Open tool →
          - article [ref=e180]:
            - generic [ref=e181]:
              - generic [ref=e182]: ↔
              - 'button "Add to favorites: JSON to CSV" [ref=e184] [cursor=pointer]': ☆
            - link "JSON to CSV Convert an array of objects to RFC 4180-style CSV. Open tool →" [ref=e185] [cursor=pointer]:
              - /url: /json-to-csv/
              - heading "JSON to CSV" [level=3] [ref=e186]
              - paragraph [ref=e187]: Convert an array of objects to RFC 4180-style CSV.
              - generic [ref=e188]: Open tool →
          - article [ref=e189]:
            - generic [ref=e190]:
              - generic [ref=e191]: ↔
              - 'button "Add to favorites: CSV to JSON" [ref=e193] [cursor=pointer]': ☆
            - link "CSV to JSON Convert CSV rows to JSON objects. Open tool →" [ref=e194] [cursor=pointer]:
              - /url: /csv-to-json/
              - heading "CSV to JSON" [level=3] [ref=e195]
              - paragraph [ref=e196]: Convert CSV rows to JSON objects.
              - generic [ref=e197]: Open tool →
          - article [ref=e198]:
            - generic [ref=e199]:
              - generic [ref=e200]: ↔
              - 'button "Add to favorites: HTML to JSX" [ref=e202] [cursor=pointer]': ☆
            - link "HTML to JSX Convert common HTML attributes to JSX. Open tool →" [ref=e203] [cursor=pointer]:
              - /url: /html-to-jsx/
              - heading "HTML to JSX" [level=3] [ref=e204]
              - paragraph [ref=e205]: Convert common HTML attributes to JSX.
              - generic [ref=e206]: Open tool →
          - article [ref=e207]:
            - generic [ref=e208]:
              - generic [ref=e209]: ↔
              - 'button "Add to favorites: String Case Converter" [ref=e211] [cursor=pointer]': ☆
            - link "String Case Converter Convert text to common identifier and title cases. Open tool →" [ref=e212] [cursor=pointer]:
              - /url: /string-case/
              - heading "String Case Converter" [level=3] [ref=e213]
              - paragraph [ref=e214]: Convert text to common identifier and title cases.
              - generic [ref=e215]: Open tool →
          - article [ref=e216]:
            - generic [ref=e217]:
              - generic [ref=e218]: ↔
              - 'button "Add to favorites: PHP to JSON" [ref=e220] [cursor=pointer]': ☆
            - link "PHP to JSON Parse a safe subset of PHP array syntax into JSON. Open tool →" [ref=e221] [cursor=pointer]:
              - /url: /php-to-json/
              - heading "PHP to JSON" [level=3] [ref=e222]
              - paragraph [ref=e223]: Parse a safe subset of PHP array syntax into JSON.
              - generic [ref=e224]: Open tool →
          - article [ref=e225]:
            - generic [ref=e226]:
              - generic [ref=e227]: ↔
              - 'button "Add to favorites: JSON to PHP" [ref=e229] [cursor=pointer]': ☆
            - link "JSON to PHP Convert JSON data to inert PHP array syntax. Open tool →" [ref=e230] [cursor=pointer]:
              - /url: /json-to-php/
              - heading "JSON to PHP" [level=3] [ref=e231]
              - paragraph [ref=e232]: Convert JSON data to inert PHP array syntax.
              - generic [ref=e233]: Open tool →
          - article [ref=e234]:
            - generic [ref=e235]:
              - generic [ref=e236]: ↔
              - 'button "Add to favorites: PHP Serializer" [ref=e238] [cursor=pointer]': ☆
            - link "PHP Serializer Serialize JSON-compatible data in PHP format. Open tool →" [ref=e239] [cursor=pointer]:
              - /url: /php-serialize/
              - heading "PHP Serializer" [level=3] [ref=e240]
              - paragraph [ref=e241]: Serialize JSON-compatible data in PHP format.
              - generic [ref=e242]: Open tool →
          - article [ref=e243]:
            - generic [ref=e244]:
              - generic [ref=e245]: ↔
              - 'button "Add to favorites: PHP Unserializer" [ref=e247] [cursor=pointer]': ☆
            - link "PHP Unserializer Parse PHP serialized scalar, array, and object-like data without PHP. Open tool →" [ref=e248] [cursor=pointer]:
              - /url: /php-unserialize/
              - heading "PHP Unserializer" [level=3] [ref=e249]
              - paragraph [ref=e250]: Parse PHP serialized scalar, array, and object-like data without PHP.
              - generic [ref=e251]: Open tool →
          - article [ref=e252]:
            - generic [ref=e253]:
              - generic [ref=e254]: ↔
              - 'button "Add to favorites: SVG to CSS" [ref=e256] [cursor=pointer]': ☆
            - link "SVG to CSS Create an encoded CSS background-image from SVG. Open tool →" [ref=e257] [cursor=pointer]:
              - /url: /svg-to-css/
              - heading "SVG to CSS" [level=3] [ref=e258]
              - paragraph [ref=e259]: Create an encoded CSS background-image from SVG.
              - generic [ref=e260]: Open tool →
          - article [ref=e261]:
            - generic [ref=e262]:
              - generic [ref=e263]: ↔
              - 'button "Add to favorites: cURL to Code" [ref=e265] [cursor=pointer]': ☆
            - link "cURL to Code Parse a cURL command without executing it and emit code. Open tool →" [ref=e266] [cursor=pointer]:
              - /url: /curl-to-code/
              - heading "cURL to Code" [level=3] [ref=e267]
              - paragraph [ref=e268]: Parse a cURL command without executing it and emit code.
              - generic [ref=e269]: Open tool →
          - article [ref=e270]:
            - generic [ref=e271]:
              - generic [ref=e272]: ↔
              - 'button "Add to favorites: JSON to Code" [ref=e274] [cursor=pointer]': ☆
            - link "JSON to Code Infer a root model for common programming languages. Open tool →" [ref=e275] [cursor=pointer]:
              - /url: /json-to-code/
              - heading "JSON to Code" [level=3] [ref=e276]
              - paragraph [ref=e277]: Infer a root model for common programming languages.
              - generic [ref=e278]: Open tool →
          - article [ref=e279]:
            - generic [ref=e280]:
              - generic [ref=e281]: ↔
              - 'button "Add to favorites: Hex to ASCII" [ref=e283] [cursor=pointer]': ☆
            - link "Hex to ASCII Decode hexadecimal bytes. Open tool →" [ref=e284] [cursor=pointer]:
              - /url: /hex-to-ascii/
              - heading "Hex to ASCII" [level=3] [ref=e285]
              - paragraph [ref=e286]: Decode hexadecimal bytes.
              - generic [ref=e287]: Open tool →
          - article [ref=e288]:
            - generic [ref=e289]:
              - generic [ref=e290]: ↔
              - 'button "Add to favorites: ASCII to Hex" [ref=e292] [cursor=pointer]': ☆
            - link "ASCII to Hex Encode text as hexadecimal UTF-8 bytes. Open tool →" [ref=e293] [cursor=pointer]:
              - /url: /ascii-to-hex/
              - heading "ASCII to Hex" [level=3] [ref=e294]
              - paragraph [ref=e295]: Encode text as hexadecimal UTF-8 bytes.
              - generic [ref=e296]: Open tool →
      - region "Inspect" [ref=e297]:
        - generic [ref=e298]:
          - generic [ref=e299]: Category
          - heading "Inspect" [level=2] [ref=e300]
        - generic [ref=e301]:
          - article [ref=e302]:
            - generic [ref=e303]:
              - generic [ref=e304]: ⌁
              - 'button "Add to favorites: Unix Time Converter" [ref=e306] [cursor=pointer]': ☆
            - link "Unix Time Converter Convert Unix seconds, milliseconds, microseconds, or nanoseconds. Open tool →" [ref=e307] [cursor=pointer]:
              - /url: /unix-time/
              - heading "Unix Time Converter" [level=3] [ref=e308]
              - paragraph [ref=e309]: Convert Unix seconds, milliseconds, microseconds, or nanoseconds.
              - generic [ref=e310]: Open tool →
          - article [ref=e311]:
            - generic [ref=e312]:
              - generic [ref=e313]: ⌁
              - 'button "Add to favorites: JWT Debugger" [ref=e315] [cursor=pointer]': ☆
            - link "JWT Debugger Decode JWT header and payload without claiming signature verification. Open tool →" [ref=e316] [cursor=pointer]:
              - /url: /jwt-debugger/
              - heading "JWT Debugger" [level=3] [ref=e317]
              - paragraph [ref=e318]: Decode JWT header and payload without claiming signature verification.
              - generic [ref=e319]: Open tool →
          - article [ref=e320]:
            - generic [ref=e321]:
              - generic [ref=e322]: ⌁
              - 'button "Add to favorites: RegExp Tester" [ref=e324] [cursor=pointer]': ☆
            - link "RegExp Tester Test a regular expression with bounded input. Open tool →" [ref=e325] [cursor=pointer]:
              - /url: /regex-tester/
              - heading "RegExp Tester" [level=3] [ref=e326]
              - paragraph [ref=e327]: Test a regular expression with bounded input.
              - generic [ref=e328]: Open tool →
          - article [ref=e329]:
            - generic [ref=e330]:
              - generic [ref=e331]: ⌁
              - 'button "Add to favorites: HTML Preview" [ref=e333] [cursor=pointer]': ☆
            - link "HTML Preview Preview HTML in a scriptless, network-blocked sandbox. Open tool →" [ref=e334] [cursor=pointer]:
              - /url: /html-preview/
              - heading "HTML Preview" [level=3] [ref=e335]
              - paragraph [ref=e336]: Preview HTML in a scriptless, network-blocked sandbox.
              - generic [ref=e337]: Open tool →
          - article [ref=e338]:
            - generic [ref=e339]:
              - generic [ref=e340]: ⌁
              - 'button "Add to favorites: Text Diff Checker" [ref=e342] [cursor=pointer]': ☆
            - link "Text Diff Checker Compare two texts line by line. Open tool →" [ref=e343] [cursor=pointer]:
              - /url: /text-diff/
              - heading "Text Diff Checker" [level=3] [ref=e344]
              - paragraph [ref=e345]: Compare two texts line by line.
              - generic [ref=e346]: Open tool →
          - article [ref=e347]:
            - generic [ref=e348]:
              - generic [ref=e349]: ⌁
              - 'button "Add to favorites: String Inspector" [ref=e351] [cursor=pointer]': ☆
            - link "String Inspector Inspect UTF-8 bytes, code points, length, and whitespace. Open tool →" [ref=e352] [cursor=pointer]:
              - /url: /string-inspector/
              - heading "String Inspector" [level=3] [ref=e353]
              - paragraph [ref=e354]: Inspect UTF-8 bytes, code points, length, and whitespace.
              - generic [ref=e355]: Open tool →
          - article [ref=e356]:
            - generic [ref=e357]:
              - generic [ref=e358]: ⌁
              - 'button "Add to favorites: Markdown Preview" [ref=e360] [cursor=pointer]': ☆
            - link "Markdown Preview Render a safe Markdown subset with raw HTML escaped. Open tool →" [ref=e361] [cursor=pointer]:
              - /url: /markdown-preview/
              - heading "Markdown Preview" [level=3] [ref=e362]
              - paragraph [ref=e363]: Render a safe Markdown subset with raw HTML escaped.
              - generic [ref=e364]: Open tool →
          - article [ref=e365]:
            - generic [ref=e366]:
              - generic [ref=e367]: ⌁
              - 'button "Add to favorites: Cron Job Parser" [ref=e369] [cursor=pointer]': ☆
            - link "Cron Job Parser Explain a five- or six-field cron expression. Open tool →" [ref=e370] [cursor=pointer]:
              - /url: /cron-parser/
              - heading "Cron Job Parser" [level=3] [ref=e371]
              - paragraph [ref=e372]: Explain a five- or six-field cron expression.
              - generic [ref=e373]: Open tool →
          - article [ref=e374]:
            - generic [ref=e375]:
              - generic [ref=e376]: ⌁
              - 'button "Add to favorites: Color Converter" [ref=e378] [cursor=pointer]': ☆
            - link "Color Converter Convert CSS hex and rgb colors. Open tool →" [ref=e379] [cursor=pointer]:
              - /url: /color-converter/
              - heading "Color Converter" [level=3] [ref=e380]
              - paragraph [ref=e381]: Convert CSS hex and rgb colors.
              - generic [ref=e382]: Open tool →
      - region "Generate" [ref=e383]:
        - generic [ref=e384]:
          - generic [ref=e385]: Category
          - heading "Generate" [level=2] [ref=e386]
        - generic [ref=e387]:
          - article [ref=e388]:
            - generic [ref=e389]:
              - generic [ref=e390]: +
              - 'button "Add to favorites: UUID / ULID Generate / Decode" [ref=e392] [cursor=pointer]': ☆
            - link "UUID / ULID Generate / Decode Generate UUID v4, UUID v7, or ULID and inspect existing IDs. Open tool →" [ref=e393] [cursor=pointer]:
              - /url: /uuid-ulid-generator/
              - heading "UUID / ULID Generate / Decode" [level=3] [ref=e394]
              - paragraph [ref=e395]: Generate UUID v4, UUID v7, or ULID and inspect existing IDs.
              - generic [ref=e396]: Open tool →
          - article [ref=e397]:
            - generic [ref=e398]:
              - generic [ref=e399]: +
              - 'button "Add to favorites: Lorem Ipsum Generator" [ref=e401] [cursor=pointer]': ☆
            - link "Lorem Ipsum Generator Generate deterministic placeholder paragraphs. Open tool →" [ref=e402] [cursor=pointer]:
              - /url: /lorem-ipsum/
              - heading "Lorem Ipsum Generator" [level=3] [ref=e403]
              - paragraph [ref=e404]: Generate deterministic placeholder paragraphs.
              - generic [ref=e405]: Open tool →
          - article [ref=e406]:
            - generic [ref=e407]:
              - generic [ref=e408]: +
              - 'button "Add to favorites: QR Code Reader / Generator" [ref=e410] [cursor=pointer]': ☆
            - link "QR Code Reader / Generator Generate QR images and decode supplied pixel data locally. Open tool →" [ref=e411] [cursor=pointer]:
              - /url: /qr-code/
              - heading "QR Code Reader / Generator" [level=3] [ref=e412]
              - paragraph [ref=e413]: Generate QR images and decode supplied pixel data locally.
              - generic [ref=e414]: Open tool →
          - article [ref=e415]:
            - generic [ref=e416]:
              - generic [ref=e417]: +
              - 'button "Add to favorites: Hash Generator" [ref=e419] [cursor=pointer]': ☆
            - link "Hash Generator Generate common cryptographic and legacy digests locally. Open tool →" [ref=e420] [cursor=pointer]:
              - /url: /hash-generator/
              - heading "Hash Generator" [level=3] [ref=e421]
              - paragraph [ref=e422]: Generate common cryptographic and legacy digests locally.
              - generic [ref=e423]: Open tool →
          - article [ref=e424]:
            - generic [ref=e425]:
              - generic [ref=e426]: +
              - 'button "Add to favorites: Random String Generator" [ref=e428] [cursor=pointer]': ☆
            - link "Random String Generator Generate random strings, passwords, Nano IDs, or license groups. Open tool →" [ref=e429] [cursor=pointer]:
              - /url: /random-string/
              - heading "Random String Generator" [level=3] [ref=e430]
              - paragraph [ref=e431]: Generate random strings, passwords, Nano IDs, or license groups.
              - generic [ref=e432]: Open tool →
      - region "Encode and decode" [ref=e433]:
        - generic [ref=e434]:
          - generic [ref=e435]: Category
          - heading "Encode and decode" [level=2] [ref=e436]
        - generic [ref=e437]:
          - article [ref=e438]:
            - generic [ref=e439]:
              - generic [ref=e440]: /%
              - 'button "Add to favorites: Base64 String Encode / Decode" [ref=e442] [cursor=pointer]': ☆
            - link "Base64 String Encode / Decode Encode or decode Base64 and Base64URL text. Open tool →" [ref=e443] [cursor=pointer]:
              - /url: /base64-string/
              - heading "Base64 String Encode / Decode" [level=3] [ref=e444]
              - paragraph [ref=e445]: Encode or decode Base64 and Base64URL text.
              - generic [ref=e446]: Open tool →
          - article [ref=e447]:
            - generic [ref=e448]:
              - generic [ref=e449]: /%
              - 'button "Add to favorites: Base64 Image Encode / Decode" [ref=e451] [cursor=pointer]': ☆
            - link "Base64 Image Encode / Decode Create or inspect image data URLs locally. Open tool →" [ref=e452] [cursor=pointer]:
              - /url: /base64-image/
              - heading "Base64 Image Encode / Decode" [level=3] [ref=e453]
              - paragraph [ref=e454]: Create or inspect image data URLs locally.
              - generic [ref=e455]: Open tool →
          - article [ref=e456]:
            - generic [ref=e457]:
              - generic [ref=e458]: /%
              - 'button "Add to favorites: URL Encode / Decode" [ref=e460] [cursor=pointer]': ☆
            - link "URL Encode / Decode Encode or decode URL components. Open tool →" [ref=e461] [cursor=pointer]:
              - /url: /url-codec/
              - heading "URL Encode / Decode" [level=3] [ref=e462]
              - paragraph [ref=e463]: Encode or decode URL components.
              - generic [ref=e464]: Open tool →
          - article [ref=e465]:
            - generic [ref=e466]:
              - generic [ref=e467]: /%
              - 'button "Add to favorites: HTML Entity Encode / Decode" [ref=e469] [cursor=pointer]': ☆
            - link "HTML Entity Encode / Decode Encode or decode HTML entities as text. Open tool →" [ref=e470] [cursor=pointer]:
              - /url: /html-entity/
              - heading "HTML Entity Encode / Decode" [level=3] [ref=e471]
              - paragraph [ref=e472]: Encode or decode HTML entities as text.
              - generic [ref=e473]: Open tool →
          - article [ref=e474]:
            - generic [ref=e475]:
              - generic [ref=e476]: /%
              - 'button "Add to favorites: Backslash Escape / Unescape" [ref=e478] [cursor=pointer]': ☆
            - link "Backslash Escape / Unescape Escape or unescape common backslash sequences. Open tool →" [ref=e479] [cursor=pointer]:
              - /url: /backslash-codec/
              - heading "Backslash Escape / Unescape" [level=3] [ref=e480]
              - paragraph [ref=e481]: Escape or unescape common backslash sequences.
              - generic [ref=e482]: Open tool →
          - article [ref=e483]:
            - generic [ref=e484]:
              - generic [ref=e485]: /%
              - 'button "Add to favorites: Certificate Decoder (X.509)" [ref=e487] [cursor=pointer]': ☆
            - link "Certificate Decoder (X.509) Inspect a PEM or DER X.509 certificate locally. Open tool →" [ref=e488] [cursor=pointer]:
              - /url: /x509-decoder/
              - heading "Certificate Decoder (X.509)" [level=3] [ref=e489]
              - paragraph [ref=e490]: Inspect a PEM or DER X.509 certificate locally.
              - generic [ref=e491]: Open tool →
          - article [ref=e492]:
            - generic [ref=e493]:
              - generic [ref=e494]: /%
              - 'button "Add to favorites: Repair garbled text" [ref=e496] [cursor=pointer]': ☆
            - link "Repair garbled text Reverse a wrong character encoding with a selectable original charset. Open tool →" [ref=e497] [cursor=pointer]:
              - /url: /mojibake-repair/
              - heading "Repair garbled text" [level=3] [ref=e498]
              - paragraph [ref=e499]: Reverse a wrong character encoding with a selectable original charset.
              - generic [ref=e500]: Open tool →
          - article [ref=e501]:
            - generic [ref=e502]:
              - generic [ref=e503]: /%
              - 'button "Add to favorites: Classical cipher alternatives" [ref=e505] [cursor=pointer]': ☆
            - link "Classical cipher alternatives Compare all Caesar shifts, or use Atbash, A1Z26 and Vigenere with your key. Open tool →" [ref=e506] [cursor=pointer]:
              - /url: /classical-cipher/
              - heading "Classical cipher alternatives" [level=3] [ref=e507]
              - paragraph [ref=e508]: Compare all Caesar shifts, or use Atbash, A1Z26 and Vigenere with your key.
              - generic [ref=e509]: Open tool →
  - contentinfo [ref=e510]:
    - generic [ref=e511]:
      - link "decod.ing" [ref=e512] [cursor=pointer]:
        - /url: /
        - img [ref=e513]
        - generic [ref=e518]: decod.ing
      - paragraph [ref=e519]: Unknown text. Clear answers. On this device.
    - generic [ref=e520]:
      - link "Device data" [ref=e521] [cursor=pointer]:
        - /url: /data/
      - link "Check local processing" [ref=e522] [cursor=pointer]:
        - /url: /proof/
      - link "Bookmarklet" [ref=e523] [cursor=pointer]:
        - /url: /bookmarklet/
      - link "Sponsor" [ref=e524] [cursor=pointer]:
        - /url: /sponsor/
      - link "49 Tools" [ref=e525] [cursor=pointer]:
        - /url: /tools/
      - link "Privacy" [ref=e526] [cursor=pointer]:
        - /url: /privacy/
      - link "Terms" [ref=e527] [cursor=pointer]:
        - /url: /terms/
      - link "Support" [ref=e528] [cursor=pointer]:
        - /url: /support/
      - link "Method" [ref=e529] [cursor=pointer]:
        - /url: /methodology/
      - link "Desktop" [ref=e530] [cursor=pointer]:
        - /url: /download/
      - link "Changelog" [ref=e531] [cursor=pointer]:
        - /url: /changelog/
      - link "About" [ref=e532] [cursor=pointer]:
        - /url: /about/
    - generic [ref=e533]:
      - paragraph [ref=e534]:
        - generic [ref=e535]: No account. No upload. No generative AI. No tracking ads.
        - generic [ref=e536]: MUNOPS (문옵스) · Build 9047f35 · 63 formats
      - generic [ref=e538]:
        - checkbox "Count actions only" [checked] [ref=e539]
        - text: Count actions only
```

# Test source

```ts
  56  |   page,
  57  | }) => {
  58  |   await page.goto('/')
  59  |   await page.getByLabel('Paste text or drop a file').fill('deadbeef')
  60  |   await expect(page.locator('.answer-verdict')).toContainText('not certain')
  61  |   await openAdvanced(page)
  62  |   const chain = page.getByRole('tree', { name: 'Decode chain' })
  63  |   await expect(chain.getByLabel(/^Step 1:/)).toBeVisible()
  64  |   await expect(chain.getByText(/Input: 8 bytes/)).toBeVisible()
  65  |   await page.getByRole('button', { name: 'Possible formats', exact: true }).click()
  66  |   const options = page.getByRole('listbox', { name: 'Possible formats' }).getByRole('option')
  67  |   await expect(options).toHaveCount(2)
  68  |   await expect(options.first()).toContainText(/Hexadecimal bytes|Base64/)
  69  | })
  70  | 
  71  | test('plays a local copy cue only after an explicit successful copy and persists its control', async ({
  72  |   page,
  73  |   context,
  74  | }) => {
  75  |   await context.grantPermissions(['clipboard-read', 'clipboard-write'])
  76  |   await page.addInitScript(() => {
  77  |     type FeedbackWindow = Window & { __copyFeedbackStarts?: number }
  78  |     const feedbackWindow = window as FeedbackWindow
  79  |     feedbackWindow.__copyFeedbackStarts = 0
  80  |     class FakeAudioContext {
  81  |       currentTime = 0
  82  |       destination = {}
  83  |       resume = async () => undefined
  84  |       createGain = () => ({
  85  |         gain: { setValueAtTime: () => undefined, linearRampToValueAtTime: () => undefined },
  86  |         connect: () => undefined,
  87  |       })
  88  |       createOscillator = () => ({
  89  |         frequency: { setValueAtTime: () => undefined },
  90  |         type: 'sine',
  91  |         connect: () => undefined,
  92  |         start: () => {
  93  |           feedbackWindow.__copyFeedbackStarts = (feedbackWindow.__copyFeedbackStarts ?? 0) + 1
  94  |         },
  95  |         stop: () => undefined,
  96  |       })
  97  |     }
  98  |     Object.defineProperty(window, 'AudioContext', { configurable: true, value: FakeAudioContext })
  99  |   })
  100 |   await page.goto('/')
  101 |   await page.getByLabel('Paste text or drop a file').fill('dGVzdA==')
  102 |   await page.getByLabel('Paste text or drop a file').blur()
  103 |   await page.getByRole('button', { name: 'Copy', exact: true }).click()
  104 |   await expect(page.getByText('Selected result copied.')).toBeVisible()
  105 |   await expect
  106 |     .poll(() =>
  107 |       page.evaluate(
  108 |         () => (window as Window & { __copyFeedbackStarts?: number }).__copyFeedbackStarts,
  109 |       ),
  110 |     )
  111 |     .toBe(2)
  112 | 
  113 |   await page.locator('.copy-feedback-settings summary').click()
  114 |   const enabled = page.getByRole('checkbox', { name: 'Play a sound after copying' })
  115 |   await enabled.uncheck()
  116 |   await page.getByRole('button', { name: 'Copy', exact: true }).click()
  117 |   await expect
  118 |     .poll(() =>
  119 |       page.evaluate(
  120 |         () => (window as Window & { __copyFeedbackStarts?: number }).__copyFeedbackStarts,
  121 |       ),
  122 |     )
  123 |     .toBe(2)
  124 |   await expect(page.evaluate(() => localStorage.getItem('decoding-copy-feedback'))).resolves.toBe(
  125 |     '{"enabled":false,"volume":0.3}',
  126 |   )
  127 | })
  128 | 
  129 | test('lists all searchable tools', async ({ page }) => {
  130 |   await page.goto('/tools/')
  131 |   await expect(page.locator('.catalog-shell')).toHaveAttribute('data-hydrated', 'true')
  132 |   await expect(page.getByText('49 of 49 tools')).toBeVisible()
  133 |   await expect(page.locator('.tool-card')).toHaveCount(49)
  134 |   await page.getByPlaceholder(/format JSON/).fill('certificate')
  135 |   await expect(page.locator('.tool-card')).toHaveCount(1)
  136 |   await expect(page.getByRole('heading', { name: /Certificate Decoder/ })).toBeVisible()
  137 | })
  138 | 
  139 | test('command palette focus, favorites, and recent tools store slugs only', async ({ page }) => {
  140 |   await page.goto('/tools/')
  141 |   const catalog = page.locator('.catalog-shell')
  142 |   await expect(catalog).toHaveAttribute('data-hydrated', 'true')
  143 |   const search = page.getByPlaceholder(/format JSON/)
  144 |   await page.keyboard.press('Control+k')
  145 |   await expect(search).toBeFocused()
  146 |   await page.getByRole('button', { name: /Add to favorites.*JSON Format \/ Validate/ }).click()
  147 |   const stored = await page.evaluate(() => ({
  148 |     favorites: localStorage.getItem('decoding-favorite-tools'),
  149 |     keys: Object.keys(localStorage),
  150 |   }))
  151 |   expect(stored.favorites).toBe('["json-format"]')
  152 |   expect(stored.keys.sort()).toEqual(['decoding-favorite-tools', 'decoding-first-visit'])
  153 |   expect(await page.evaluate(() => localStorage.getItem('decoding-first-visit'))).toMatch(
  154 |     /^\d{4}-\d\d-\d\d$/,
  155 |   )
> 156 |   await page.getByRole('link', { name: /JSON Format \/ Validate/ }).click()
      |                                                                     ^ Error: locator.click: Error: strict mode violation: getByRole('link', { name: /JSON Format \/ Validate/ }) resolved to 2 elements:
  157 |   await page.goto('/tools/')
  158 |   await expect(page.getByRole('heading', { name: 'Recent tools' })).toBeVisible()
  159 |   await expect(
  160 |     page.locator('.recent-links').getByRole('link', { name: 'JSON Format / Validate' }),
  161 |   ).toBeVisible()
  162 | })
  163 | 
  164 | test('runs a dedicated JSON formatter operation', async ({ page }) => {
  165 |   await page.goto('/json-format/')
  166 |   await expect(page.locator('.tool-workbench')).toHaveAttribute('data-hydrated', 'true')
  167 |   await page.locator('.operation-pane textarea').first().fill('{"answer":42,"local":true}')
  168 |   await runTool(page)
  169 |   await expect(page.locator('.output-view')).toContainText('"answer": 42')
  170 |   await expect(page.getByText('Valid JSON')).toBeVisible()
  171 | })
  172 | 
  173 | test('keeps the Korean journey in user-facing language from discovery through result', async ({
  174 |   page,
  175 | }) => {
  176 |   await page.goto('/ko/')
  177 |   await expect(page.locator('meta[name="robots"]')).toHaveCount(0)
  178 |   await expect(page.locator('link[rel="alternate"][hreflang="ko"]')).toHaveAttribute(
  179 |     'href',
  180 |     'https://decod.ing/ko/',
  181 |   )
  182 |   await expect(page.getByText('한국어 번역 검토 중')).toHaveCount(0)
  183 |   await expect(
  184 |     page.getByRole('heading', { name: '이게 뭔지 모르겠다면 여기에 붙여넣으세요' }),
  185 |   ).toBeVisible()
  186 |   await expect(page.locator('.hero h1 br')).toHaveCount(0)
  187 |   await expect(
  188 |     page.getByRole('group', { name: '이런 걸 들고 오셨나요? 눌러서 미리 보기' }),
  189 |   ).toContainText('깨진 글자')
  190 | 
  191 |   await page.getByLabel('텍스트를 붙여넣거나 파일을 놓으세요').fill('dGVzdA==')
  192 |   await openAdvanced(page)
  193 |   await expect(page.locator('.evidence-stack').first()).toContainText('Base64에서 쓰는 문자')
  194 | 
  195 |   await page.goto('/ko/tools/')
  196 |   await expect(page.getByRole('heading', { name: '필요한 변환과 검사를 한곳에서.' })).toBeVisible()
  197 |   await expect(page.getByRole('heading', { name: '정리', exact: true })).toBeVisible()
  198 |   await expect(page.getByRole('heading', { name: 'JSON 정리와 문법 확인' })).toBeVisible()
  199 |   await expect(page.locator('.tool-card').first()).toContainText(
  200 |     'JSON 들여쓰기를 정리하거나 한 줄로 줄이고 문법 오류를 확인합니다.',
  201 |   )
  202 | 
  203 |   await page.goto('/ko/json-format/')
  204 |   await expect(page.getByRole('heading', { name: 'JSON 정리와 문법 확인', level: 1 })).toBeVisible()
  205 |   await page.locator('.operation-pane textarea').first().fill('{"answer":42}')
  206 |   await expect(page.locator('.tool-live-note')).toContainText('치는 대로 결과가 바뀌어요.')
  207 |   await expect(page.getByText('JSON 문법을 확인했습니다.')).toBeVisible()
  208 |   await expect(page.getByRole('heading', { name: '텍스트 결과' })).toBeVisible()
  209 | 
  210 |   await page.goto('/ko/curl-to-code/')
  211 |   await expect(page.locator('option[value="javascript"]')).toHaveText('JavaScript')
  212 |   await expect(page.getByRole('option', { name: 'javascript', exact: true })).toHaveCount(0)
  213 | 
  214 |   await page.goto('/ko/string-case/')
  215 |   await expect(page.locator('option[value="camel"]')).toHaveText('camelCase')
  216 |   await expect(page.getByRole('option', { name: 'camel', exact: true })).toHaveCount(0)
  217 | })
  218 | 
  219 | test.describe('Korean first-visit selection', () => {
  220 |   test.use({ locale: 'ko-KR' })
  221 | 
  222 |   for (const width of [320, 390]) {
  223 |     test(`opens Korean without a suggestion banner at ${width}px`, async ({ page }) => {
  224 |       await page.setViewportSize({ width, height: 800 })
  225 |       await page.goto('/')
  226 |       if (width === 320) {
  227 |         await page.evaluate(() => {
  228 |           document.documentElement.style.fontSize = '200%'
  229 |         })
  230 |       }
  231 | 
  232 |       await expect(page).toHaveURL(/\/ko\/$/)
  233 |       await expect(page.locator('#locale-suggestion')).toHaveCount(0)
  234 |       await expect(page.locator('html')).toHaveAttribute('lang', 'ko')
  235 |       expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(
  236 |         width,
  237 |       )
  238 |     })
  239 |   }
  240 | })
  241 | 
  242 | test('renders HTML preview inside a locked sandbox', async ({ page }) => {
  243 |   await page.goto('/html-preview/')
  244 |   await expect(page.locator('.tool-workbench')).toHaveAttribute('data-hydrated', 'true')
  245 |   await runTool(page)
  246 |   const frame = page.locator('iframe.safe-preview')
  247 |   await expect(frame).toHaveAttribute('sandbox', '')
  248 |   await expect(frame).toHaveAttribute('srcdoc', /default-src 'none'/)
  249 | })
  250 | 
  251 | test('publishes reachable terms and safe support routes from the global footer', async ({
  252 |   page,
  253 | }) => {
  254 |   await page.goto('/')
  255 |   const footer = page.locator('.site-footer')
  256 |   await expect(footer.getByRole('link', { name: 'Terms' })).toHaveAttribute('href', '/terms/')
```
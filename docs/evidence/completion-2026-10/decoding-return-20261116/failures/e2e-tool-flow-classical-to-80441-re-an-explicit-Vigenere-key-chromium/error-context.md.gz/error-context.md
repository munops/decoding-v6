# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: e2e/tool-flow.spec.ts >> classical tools compare shifts and require an explicit Vigenere key
- Location: tests/e2e/tool-flow.spec.ts:29:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.output-pane .output-view')
Expected substring: "Hello"
Received string:    "Run the tool to see local output."
Timeout: 8000ms

Call log:
  - Expect "toContainText" with timeout 8000ms
  - waiting for locator('.output-pane .output-view')
    20 × locator resolved to <pre class="output-view">…</pre>
       - unexpected value "Run the tool to see local output."

```

```yaml
- code: Run the tool to see local output.
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test'
  2   | 
  3   | test('pure tools update immediately, hand the final value to decoding, and keep Korean locale', async ({
  4   |   page,
  5   | }) => {
  6   |   await page.goto('/ko/url-codec/')
  7   |   await page.locator('.operation-pane textarea').fill('%ED%95%9C%EA%B8%80%20test')
  8   |   await expect(page.locator('.output-pane .output-view')).toHaveText('한글 test')
  9   |   await expect(page.getByRole('button', { name: '기기에서 실행' })).toHaveCount(0)
  10  |   await page.getByRole('button', { name: '이 결과를 더 풀기', exact: true }).click()
  11  |   await page.waitForURL('**/ko/')
  12  |   await expect(page.getByLabel('텍스트를 붙여넣거나 파일을 놓으세요')).toHaveValue('한글 test')
  13  |   expect(await page.evaluate(() => sessionStorage.getItem('decoding-handoff'))).toBeNull()
  14  | })
  15  | 
  16  | test('Korean task aliases find repair, QR and formatting tools', async ({ page }) => {
  17  |   await page.goto('/ko/tools/')
  18  |   const search = page.getByRole('searchbox')
  19  |   for (const [term, href] of [
  20  |     ['깨짐', '/ko/mojibake-repair/'],
  21  |     ['큐알', '/ko/qr-code/'],
  22  |     ['줄맞추기', '/ko/json-format/'],
  23  |   ]) {
  24  |     await search.fill(term!)
  25  |     await expect(page.locator(`.tool-card a[href="${href}"]`).first()).toBeVisible()
  26  |   }
  27  | })
  28  | 
  29  | test('classical tools compare shifts and require an explicit Vigenere key', async ({ page }) => {
  30  |   await page.goto('/classical-cipher/')
  31  |   await page.locator('.operation-pane textarea').fill('Uryyb')
> 32  |   await expect(page.locator('.output-pane .output-view')).toContainText('Hello')
      |                                                           ^ Error: expect(locator).toContainText(expected) failed
  33  |   await expect(page.locator('.output-pane .output-view')).toContainText('"shift": 25')
  34  |   await page
  35  |     .getByRole('combobox', { name: 'Direction', exact: true })
  36  |     .first()
  37  |     .selectOption('vigenere')
  38  |   await page.getByLabel('Your key (letters only)').fill('LEMON')
  39  |   await page.locator('.operation-pane textarea').fill('LXFOPVEFRNHR')
  40  |   await expect(page.locator('.output-pane .output-view')).toHaveText('ATTACKATDAWN')
  41  | })
  42  | 
  43  | test('decoder codecs are available immediately after service worker installation', async ({
  44  |   page,
  45  |   context,
  46  | }) => {
  47  |   await page.goto('/')
  48  |   await page.evaluate(async () => {
  49  |     await navigator.serviceWorker.register('/sw.js')
  50  |     await navigator.serviceWorker.ready
  51  |   })
  52  |   await page.reload()
  53  |   await context.setOffline(true)
  54  |   const content = Buffer.from('{"offline":true}')
  55  |   const n = content.length * 8 + 1
  56  |   const zstd = Buffer.from([
  57  |     0x28,
  58  |     0xb5,
  59  |     0x2f,
  60  |     0xfd,
  61  |     0x20,
  62  |     content.length,
  63  |     n & 255,
  64  |     n >> 8,
  65  |     0,
  66  |     ...content,
  67  |   ]).toString('hex')
  68  |   for (const [input, expected] of [
  69  |     ['81a16101', '"a": 1'],
  70  |     ['d9d9f7a1616101', '"a": 1'],
  71  |     ['[package]\nname = "offline-synthetic"\nversion = "1.0.0"', 'offline-synthetic'],
  72  |     [zstd, '"offline": true'],
  73  |   ]) {
  74  |     await page.getByLabel('Paste text or drop a file').fill(input!)
  75  |     await expect(page.locator('.answer-final .output-view')).toContainText(expected!)
  76  |     await expect(page.locator('.answer-card')).not.toContainText('not cached')
  77  |   }
  78  | })
  79  | 
  80  | test('idle installation caches every current-language tool and its lazy runtime', async ({
  81  |   page,
  82  |   context,
  83  | }) => {
  84  |   await page.goto('/ko/')
  85  |   await page.evaluate(async () => {
  86  |     await navigator.serviceWorker.register('/sw.js')
  87  |     const registration = await navigator.serviceWorker.ready
  88  |     registration.active?.postMessage({ type: 'decoding:cache-tools', locale: 'ko' })
  89  |   })
  90  |   await expect
  91  |     .poll(
  92  |       () =>
  93  |         page.evaluate(async () => {
  94  |           const inventory = await fetch('/offline-assets.json').then((response) => response.json())
  95  |           const key = (await caches.keys()).find((key) => key.startsWith('decoding-v6-shell-'))!
  96  |           const cache = await caches.open(key)
  97  |           const paths: string[] = [
  98  |             ...inventory.assets,
  99  |             ...inventory.tools.filter((path: string) => path.startsWith('/ko/')),
  100 |           ]
  101 |           return (
  102 |             await Promise.all(paths.map((path) => cache.match(path, { ignoreVary: true })))
  103 |           ).every(Boolean)
  104 |         }),
  105 |       { timeout: 30000 },
  106 |     )
  107 |     .toBe(true)
  108 |   await context.setOffline(true)
  109 |   await page.goto('/ko/mojibake-repair/')
  110 |   await expect(page.locator('.output-pane .output-view')).toHaveText('한글')
  111 |   await page.goto('/ko/classical-cipher/')
  112 |   await expect(page.locator('.output-pane .output-view')).toContainText('Hello')
  113 | })
  114 | 
```
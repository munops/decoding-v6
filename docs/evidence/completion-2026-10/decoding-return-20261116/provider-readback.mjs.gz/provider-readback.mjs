import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
const dir='/Users/minhan/workspace/decoding-v6/.wrangler/decoding-return-20261116';
const cfg=JSON.parse(readFileSync(dir+'/execution.json','utf8'));
const mode=process.argv[2];
const env={...process.env,CLOUDFLARE_ACCOUNT_ID:cfg.account,WRANGLER_SEND_METRICS:'false',WRANGLER_WRITE_LOGS:'false'};
const cli=args=>JSON.parse(execFileSync('pnpm',['exec','wrangler',...args],{cwd:cfg.root,env,encoding:'utf8',stdio:['ignore','pipe','pipe'],maxBuffer:8*1024*1024}));
const hash=b=>createHash('sha256').update(b).digest('hex');
try {
 const rows=cli(['deployments','list','--name','decoding-v6','--json']);
 const latest=rows.sort((a,b)=>Date.parse(b.created_on)-Date.parse(a.created_on))[0];
 if(latest.versions.length!==1||latest.versions[0].percentage!==100)throw Error('traffic');
 const version=cli(['versions','view',latest.versions[0].version_id,'--name','decoding-v6','--json']);
 const bindings=version.resources.bindings.map(b=>({name:b.name,type:b.type,...(b.dataset?{dataset:b.dataset}:{})})).sort((a,b)=>a.name.localeCompare(b.name));
 if(JSON.stringify(bindings)!==JSON.stringify([...cfg.before.bindings].sort((a,b)=>a.name.localeCompare(b.name))))throw Error('bindings');
 const origins=['https://decod.ing','https://www.decod.ing','https://decoding-v6.wjstks3474.workers.dev'];
 const health=[];
 for(const origin of origins){const response=await fetch(origin+'/healthz',{signal:AbortSignal.timeout(15000),headers:{'Cache-Control':'no-cache'}});if(!response.ok)throw Error('health status');const body=await response.json();if(body.ok!==true||body.service!=='decoding-v6'||body.revision!==(mode==='before'?cfg.before.health.revision:cfg.sourceRevision))throw Error('health revision');health.push({origin,status:response.status,...body});}
 if(mode==='before'&&(latest.id!==cfg.before.deploymentId||latest.versions[0].version_id!==cfg.before.versions[0].version_id))throw Error('before drift');
 if(mode==='after'&&latest.versions[0].version_id===cfg.before.versions[0].version_id)throw Error('no new version');
 let identity;
 if(mode==='after') {const response=await fetch('https://decod.ing/manifest.webmanifest',{signal:AbortSignal.timeout(15000)});const m=await response.json();const picked={origin:'https://decod.ing',name:m.name,short_name:m.short_name};identity={...picked,fingerprint:hash(JSON.stringify(picked))};if(identity.fingerprint!=='0630fe0decac66174b6aebb6e6f89e3730df11046bb61f42c5837d679a981c89')throw Error('manifest identity');}
 const result={checkedAt:new Date().toISOString(),state:'verified',mode,deployment:{id:latest.id,versions:latest.versions},health,bindings,...(identity?{identity}:{}),sourceRevision:cfg.sourceRevision,artifactDigest:cfg.artifactDigest};
 if(mode==='after')writeFileSync(dir+'/deploy-after.json',JSON.stringify(result,null,2),{flag:'wx',flush:true});
 console.log(JSON.stringify(result));
}catch{console.error('DECODING_PROVIDER_READBACK_FAILED: no raw provider response was recorded');process.exitCode=1;}
